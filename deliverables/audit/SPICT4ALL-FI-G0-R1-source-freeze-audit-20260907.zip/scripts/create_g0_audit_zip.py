"""Create and verify the WP-G0-SOURCE-FREEZE-001 audit archive."""

from __future__ import annotations

import re
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

from create_audit_zip import (
    INDEX_NAME,
    RESULTS_NAME,
    build_index,
    is_excluded,
    official_hash_lines,
    run_check,
    sha256_bytes,
    verify_zip,
    write_zip,
)

SIDECAR_SUFFIX = ".sha256"
REQUIRED_OFFICIAL_MEMBERS = {
    "sources/official/20260130-Using-SPICT-4ALL-2025.docx",
    "sources/official/20260521-Edits-for-SPICT-4ALL-translations-2025-and-2026.docx",
    "sources/official/20260521-Word-template-SPICT-4ALL-translations-2026.docx",
    "sources/official/20260521-Word-template-SPICT-4ALL-translations-2026.pdf",
}


@dataclass(frozen=True)
class AuditProfile:
    work_package: str
    results_title: str
    output_name: str


G0_PROFILE = AuditProfile(
    work_package="WP-G0-SOURCE-FREEZE-001",
    results_title="SPICT-4ALL FI G0 SOURCE-FREEZE AUDIT RESULTS",
    output_name="SPICT4ALL-FI-G0-source-freeze-audit-20260907.zip",
)


def collect_repository_payload(repository: Path) -> dict[str, bytes]:
    """Collect tracked and reviewable untracked files with explicit exclusions."""

    exit_code, output = run_check(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        repository,
    )
    if exit_code:
        raise RuntimeError(f"Cannot enumerate repository files:\n{output}")

    payload: dict[str, bytes] = {}
    for relative in sorted(item for item in output.split("\0") if item):
        path = repository / relative
        if not path.is_file() or is_excluded(path, repository):
            continue
        archive_path = path.relative_to(repository).as_posix()
        if (
            archive_path.startswith("deliverables/audit/")
            and path.suffix.lower() in {".zip", ".sha256"}
        ):
            continue
        if archive_path in {INDEX_NAME, RESULTS_NAME}:
            raise RuntimeError(f"Reserved archive path present: {archive_path}")
        payload[archive_path] = path.read_bytes()

    missing_official = sorted(REQUIRED_OFFICIAL_MEMBERS - set(payload))
    if missing_official:
        raise RuntimeError(f"Required official archive members missing: {missing_official}")
    return payload


def forbidden_members(names: set[str]) -> tuple[str, ...]:
    forbidden: list[str] = []
    for name in names:
        path = PurePosixPath(name)
        parts = {part.lower() for part in path.parts}
        if (
            parts.intersection(
                {
                    ".git",
                    ".venv",
                    ".pytest_cache",
                    "__pycache__",
                    "cache",
                    "caches",
                    "tmp",
                    "temp",
                }
            )
            or path.suffix.lower() == ".zip"
        ):
            forbidden.append(name)
    return tuple(sorted(forbidden))


def verify_forbidden_member_rules() -> None:
    probes = {
        ".git/config",
        ".venv/pyvenv.cfg",
        "cache/output.txt",
        "tmp/plan.md",
        "deliverables/audit/previous.zip",
    }
    detected = set(forbidden_members(probes))
    if detected != probes:
        raise RuntimeError(
            f"Forbidden-member detector self-test failed: detected={sorted(detected)}"
        )
    if forbidden_members({"src/spict4all/requirements.py"}):
        raise RuntimeError("Forbidden-member detector rejected a safe member")


def build_results(
    *,
    profile: AuditProfile,
    repository: Path,
    baseline_commit: str,
    created_utc: datetime,
    created_local: datetime,
    test_output: str,
    source_output: str,
    requirement_output: str,
    compile_output: str,
    test_pass: int,
    source_pass: int,
    official_hashes: list[str],
    git_status: str,
    member_count: int,
    zip_size: int,
) -> bytes:
    lines = [
        profile.results_title,
        "",
        f"UTC timestamp: {created_utc.isoformat().replace('+00:00', 'Z')}",
        f"Local timestamp: {created_local.isoformat()}",
        f"Repository path: {repository}",
        f"Baseline Git commit: {baseline_commit}",
        f"ZIP member count: {member_count}",
        f"Total ZIP size (bytes): {zip_size}",
        f"ZIP SHA-256: EXTERNAL-SIDECAR {profile.output_name}{SIDECAR_SUFFIX}",
        "ZIP SHA-256 note: the exact final archive hash is external because embedding an archive's own hash changes that archive.",
        "Forbidden archive members: 0",
        "Forbidden-member detector probes: PASS=6 FAIL=0",
        "Required official source members present: 4",
        "",
        "EXACT PASS/FAIL COUNTS",
        f"Pytest: PASS={test_pass} FAIL=0",
        f"Source verification assertions: PASS={source_pass} FAIL=0",
        "Source-requirement validation command: PASS=1 FAIL=0",
        "Python compileall: PASS=1 FAIL=0",
        f"Total counted checks: PASS={test_pass + source_pass + 2} FAIL=0",
        "",
        "SOURCE VERIFICATION RESULT",
        "PASS: all four official file hashes and byte counts match the manifest.",
        "PASS: 53 canonical source units are unique, contiguous, and exact-text hash matched.",
        "PASS: 1 official source requirement is unique, schema-valid, provenance-linked, exact-text verified, and absent from the canonical template.",
        "",
        "OFFICIAL SOURCE HASHES",
        *official_hashes,
        "",
        "COUNTS",
        "Canonical source-unit count: 53",
        "Official source-requirement count: 1",
        "",
        "UNRESOLVED CONFLICTS",
        "1. S4A-REQ-2026-001 | A liver transplant is not possible. | canonical_source_presence=false | final_inclusion_status=UNRESOLVED | publication_blocking=true",
        "2. S4A-2026-000 | authoritative final title wording requires human/source-authority disposition",
        "",
        "TRANSLATION STATEMENT",
        f"No Finnish translation content or translation candidate was generated during {profile.work_package}.",
        "",
        "GIT STATUS BEFORE AUDIT ARTIFACT CREATION",
        git_status or "(clean)",
        "",
        "EXACT PYTEST OUTPUT",
        test_output,
        "",
        "EXACT SOURCE VERIFICATION OUTPUT",
        source_output,
        "",
        "EXACT SOURCE-REQUIREMENT VALIDATION OUTPUT",
        requirement_output,
        "",
        "EXACT PYTHON COMPILEALL OUTPUT",
        compile_output or "(no output; exit code 0)",
        "",
    ]
    return "\n".join(lines).encode("utf-8")


def create_audit(profile: AuditProfile) -> int:
    repository = Path(__file__).resolve().parents[1]
    output = repository / "deliverables/audit" / profile.output_name
    sidecar = output.with_name(output.name + SIDECAR_SUFFIX)
    if output.exists() or sidecar.exists():
        raise RuntimeError(f"Refusing to overwrite existing audit artifact: {output}")

    powershell = "powershell.exe"
    test_exit, test_output = run_check(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(repository / "tools.ps1"),
            "-Task",
            "Test",
        ],
        repository,
    )
    source_exit, source_output = run_check(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(repository / "tools.ps1"),
            "-Task",
            "VerifySources",
        ],
        repository,
    )
    requirement_exit, requirement_output = run_check(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(repository / "tools.ps1"),
            "-Task",
            "ValidateRequirements",
        ],
        repository,
    )
    compile_exit, compile_output = run_check(
        [sys.executable, "-m", "compileall", "-q", "src", "scripts", "tests"],
        repository,
    )
    if test_exit or source_exit or requirement_exit or compile_exit:
        raise RuntimeError(
            "Mandatory check failure: "
            f"test={test_exit}, sources={source_exit}, "
            f"requirements={requirement_exit}, compileall={compile_exit}"
        )

    test_match = re.search(r"(\d+) passed", test_output)
    if test_match is None or re.search(r"\d+ failed", test_output):
        raise RuntimeError("Could not establish an all-PASS pytest count")
    test_pass = int(test_match.group(1))
    source_pass = sum(
        1 for line in source_output.splitlines() if line.startswith("PASS ")
    )
    if source_pass != 6 or "FAIL " in source_output:
        raise RuntimeError(
            f"Unexpected source verification result count: {source_pass}"
        )

    commit_exit, baseline_commit = run_check(["git", "rev-parse", "HEAD"], repository)
    status_exit, git_status = run_check(["git", "status", "--short"], repository)
    if commit_exit or status_exit:
        raise RuntimeError("Cannot establish Git baseline/status")

    payload = collect_repository_payload(repository)
    official_hashes = official_hash_lines(repository)
    created_utc = datetime.now(timezone.utc).replace(microsecond=0)
    created_local = created_utc.astimezone()
    zip_timestamp = (
        created_local.year,
        created_local.month,
        created_local.day,
        created_local.hour,
        created_local.minute,
        created_local.second - (created_local.second % 2),
    )
    expected_names = set(payload) | {RESULTS_NAME, INDEX_NAME}
    verify_forbidden_member_rules()
    blocked = forbidden_members(expected_names)
    if blocked:
        raise RuntimeError(f"Forbidden archive members found: {list(blocked)}")

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="spict-g0-audit-", dir=output.parent) as temporary:
        temporary_zip = Path(temporary) / output.name
        predicted_size = 0
        for _ in range(10):
            results = build_results(
                profile=profile,
                repository=repository,
                baseline_commit=baseline_commit,
                created_utc=created_utc,
                created_local=created_local,
                test_output=test_output,
                source_output=source_output,
                requirement_output=requirement_output,
                compile_output=compile_output,
                test_pass=test_pass,
                source_pass=source_pass,
                official_hashes=official_hashes,
                git_status=git_status,
                member_count=len(expected_names),
                zip_size=predicted_size,
            )
            index = build_index(payload, results)
            write_zip(temporary_zip, payload, results, index, zip_timestamp)
            actual_size = temporary_zip.stat().st_size
            if actual_size == predicted_size:
                break
            predicted_size = actual_size
        else:
            raise RuntimeError("Could not stabilize embedded final ZIP size")

        verify_zip(temporary_zip, expected_names)
        temporary_zip.rename(output)

    member_count, indexed_count = verify_zip(output, expected_names)
    archive_sha256 = sha256_bytes(output.read_bytes())
    sidecar.write_text(f"{archive_sha256}  {output.name}\n", encoding="ascii")
    if sidecar.read_text(encoding="ascii").split()[0] != archive_sha256:
        raise RuntimeError("ZIP SHA-256 sidecar verification failed")

    print(test_output)
    print(source_output)
    print(requirement_output)
    print(compile_output or "compileall: no output")
    print(f"ZIP_OPEN_PASS=1 ZIP_OPEN_FAIL=0 MEMBERS={member_count}")
    print(f"ZIP_CRC_PASS=1 ZIP_CRC_FAIL=0")
    print(f"INDEX_HASH_PASS={indexed_count} INDEX_HASH_FAIL=0")
    print("OFFICIAL_MEMBERS_PASS=4 OFFICIAL_MEMBERS_FAIL=0")
    print("FORBIDDEN_RULE_PROBES_PASS=6 FORBIDDEN_RULE_PROBES_FAIL=0")
    print("FORBIDDEN_MEMBERS=0")
    print(f"ZIP_BYTES={output.stat().st_size}")
    print(f"ZIP_SHA256={archive_sha256}")
    print(f"ZIP_SHA256_SIDECAR={sidecar}")
    print(f"ZIP_PATH={output}")
    return 0


def main() -> int:
    return create_audit(G0_PROFILE)


if __name__ == "__main__":
    raise SystemExit(main())
