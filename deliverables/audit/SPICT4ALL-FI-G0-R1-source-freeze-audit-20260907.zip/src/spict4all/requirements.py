"""Source-derived OOXML change completeness and typed evidence preparation.

Visible paragraph text is composed in XML order from text in ``w:r`` runs. ``w:t``
contributes its text, ``w:tab`` contributes a tab, ``w:br``/``w:cr`` contribute a
newline, and explicit soft/no-break hyphens are retained. A change marker counts
only when it is in that visible run's own ``w:rPr``. Paragraph properties and
paragraph-mark run properties never mark visible source text. Boundary layout
whitespace is removed from paragraph source text; internal whitespace is preserved.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .artifacts import load_schema
from .errors import ArtifactValidationError, IntegrityError
from .evidence import (
    EvidenceProvenance,
    EvidenceSource,
    EvidenceSourceKind,
    FinalInclusionStatus,
    ProvenanceValue,
)
from .hashing import sha256_file, sha256_text
from .jsonl import load_jsonl
from .sources import load_source_manifest

WORD_NAMESPACE = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
WORD = f"{{{WORD_NAMESPACE}}}"
RELEVANT_WORD_PART = re.compile(
    r"^word/(?:document|header[^/]*|footer[^/]*|footnotes|endnotes)\.xml$"
)


class MarkerMechanism(str, Enum):
    HIGHLIGHT_YELLOW = "highlight_yellow"
    HIGHLIGHT_GREEN = "highlight_green"
    FONT_COLOR_ACCENT6 = "font_color_accent6"


class ConflictStatus(str, Enum):
    UNRESOLVED_CANONICAL_OMISSION = "UNRESOLVED_CANONICAL_OMISSION"
    AUTHORITY_RESOLVED = "AUTHORITY_RESOLVED"


@dataclass(frozen=True)
class SourceMarking:
    marker_type: str
    value: str | None
    theme_color: str | None
    theme_shade: str | None


@dataclass(frozen=True)
class SourceProvenance:
    document_part: str
    table_index: int | None
    row: int | None
    column: int | None
    paragraph: int | None
    paragraph_index: int | None
    marking: SourceMarking


@dataclass(frozen=True)
class SourceRequirement:
    """A provenance-locked official requirement outside the canonical namespace."""

    requirement_id: str
    exact_source_text_en: str
    exact_text_sha256: str
    official_source_filename: str
    official_source_file_sha256: str
    source_role: str
    source_provenance: SourceProvenance
    change_year: int
    canonical_source_presence: bool
    conflict_status: ConflictStatus
    translation_evidence_required: bool
    requires_human_signoff: bool
    source_authority_confirmation_required: bool
    final_inclusion_status: FinalInclusionStatus
    publication_blocking: bool
    has_authority_disposition: bool

    def __post_init__(self) -> None:
        if self.conflict_status is ConflictStatus.UNRESOLVED_CANONICAL_OMISSION:
            if (
                self.final_inclusion_status is not FinalInclusionStatus.UNRESOLVED
                or not self.publication_blocking
                or not self.source_authority_confirmation_required
            ):
                raise IntegrityError(
                    f"{self.requirement_id}: unresolved canonical omission must "
                    "remain authority-required, UNRESOLVED, and publication-blocking"
                )
        elif (
            not self.has_authority_disposition
            or self.final_inclusion_status
            not in {FinalInclusionStatus.INCLUDE, FinalInclusionStatus.EXCLUDE}
        ):
            raise IntegrityError(
                f"{self.requirement_id}: resolved conflict requires an explicit "
                "authority inclusion or exclusion disposition"
            )

    @classmethod
    def from_record(cls, record: dict[str, Any]) -> SourceRequirement:
        provenance = record["source_provenance"]
        marking = provenance["marking"]
        return cls(
            requirement_id=record["requirement_id"],
            exact_source_text_en=record["exact_source_text_en"],
            exact_text_sha256=record["exact_text_sha256"],
            official_source_filename=record["official_source_filename"],
            official_source_file_sha256=record["official_source_file_sha256"],
            source_role=record["source_role"],
            source_provenance=SourceProvenance(
                document_part=provenance["document_part"],
                table_index=provenance.get("table_index"),
                row=provenance.get("row"),
                column=provenance.get("column"),
                paragraph=provenance.get("paragraph"),
                paragraph_index=provenance.get("paragraph_index"),
                marking=SourceMarking(
                    marker_type=marking["type"],
                    value=marking.get("value", marking.get("w_val")),
                    theme_color=marking.get("theme_color"),
                    theme_shade=marking.get("theme_shade"),
                ),
            ),
            change_year=record["change_year"],
            canonical_source_presence=record["canonical_source_presence"],
            conflict_status=ConflictStatus(record["conflict_status"]),
            translation_evidence_required=record["translation_evidence_required"],
            requires_human_signoff=record["requires_human_signoff"],
            source_authority_confirmation_required=record[
                "source_authority_confirmation_required"
            ],
            final_inclusion_status=FinalInclusionStatus(
                record["final_inclusion_status"]
            ),
            publication_blocking=record["publication_blocking"],
            has_authority_disposition="authority_disposition" in record,
        )


@dataclass(frozen=True)
class WordPart:
    name: str
    root: ET.Element


@dataclass(frozen=True)
class ParagraphLocation:
    document_part: str
    paragraph_index: int
    table_index: int | None
    row: int | None
    column: int | None
    paragraph: int | None


@dataclass(frozen=True)
class MarkedRun:
    visible_text: str
    mechanism: MarkerMechanism
    value: str | None
    theme_color: str | None
    theme_shade: str | None


@dataclass(frozen=True)
class MarkedParagraph:
    visible_text: str
    location: ParagraphLocation
    marked_runs: tuple[MarkedRun, ...]


@dataclass(frozen=True)
class ChangeSpecCensus:
    marked_paragraphs: tuple[MarkedParagraph, ...]

    @property
    def yellow_highlighted_runs(self) -> int:
        return self._count(MarkerMechanism.HIGHLIGHT_YELLOW)

    @property
    def green_highlighted_runs(self) -> int:
        return self._count(MarkerMechanism.HIGHLIGHT_GREEN)

    @property
    def accent6_font_runs(self) -> int:
        return self._count(MarkerMechanism.FONT_COLOR_ACCENT6)

    def _count(self, mechanism: MarkerMechanism) -> int:
        return sum(
            run.mechanism is mechanism
            for paragraph in self.marked_paragraphs
            for run in paragraph.marked_runs
        )


@dataclass(frozen=True)
class ChangeSpecCompleteness:
    census: ChangeSpecCensus
    canonical_paragraph_count: int
    absent_from_canonical: tuple[str, ...]


@dataclass(frozen=True)
class SourceRequirementVerification:
    requirements: tuple[SourceRequirement, ...]
    completeness: ChangeSpecCompleteness


@dataclass(frozen=True)
class VerifiedOfficialSource:
    filename: str
    role: str
    path: Path
    sha256: str
    byte_count: int


def enumerate_wordprocessing_parts(path: Path) -> tuple[WordPart, ...]:
    """Parse all relevant WordprocessingML text-bearing parts in a DOCX."""

    try:
        with zipfile.ZipFile(path, "r") as document:
            names = sorted(
                name for name in document.namelist() if RELEVANT_WORD_PART.fullmatch(name)
            )
            parts = tuple(
                WordPart(name=name, root=ET.fromstring(document.read(name)))
                for name in names
            )
    except (OSError, zipfile.BadZipFile, ET.ParseError) as exc:
        raise IntegrityError(f"Cannot inspect official DOCX {path}: {exc}") from exc
    if not any(part.name == "word/document.xml" for part in parts):
        raise IntegrityError(f"Official DOCX has no word/document.xml: {path}")
    return parts


def _visible_text(element: ET.Element) -> str:
    fragments: list[str] = []
    for node in element.iter():
        if node.tag == f"{WORD}t":
            fragments.append(node.text or "")
        elif node.tag == f"{WORD}tab":
            fragments.append("\t")
        elif node.tag in {f"{WORD}br", f"{WORD}cr"}:
            fragments.append("\n")
        elif node.tag == f"{WORD}noBreakHyphen":
            fragments.append("\N{NON-BREAKING HYPHEN}")
        elif node.tag == f"{WORD}softHyphen":
            fragments.append("\N{SOFT HYPHEN}")
    return "".join(fragments)


def _paragraph_visible_text(paragraph: ET.Element) -> str:
    """Remove only boundary layout whitespace; preserve internal visible content."""

    return _visible_text(paragraph).strip(" \t\r\n")


def _table_locations(
    part: WordPart,
) -> dict[int, tuple[int, int, int, int]]:
    locations: dict[int, tuple[int, int, int, int]] = {}
    for table_index, table in enumerate(part.root.iter(f"{WORD}tbl")):
        for row_index, row in enumerate(table.findall(f"{WORD}tr")):
            for column_index, cell in enumerate(row.findall(f"{WORD}tc")):
                for paragraph_index, paragraph in enumerate(cell.iter(f"{WORD}p")):
                    locations.setdefault(
                        id(paragraph),
                        (table_index, row_index, column_index, paragraph_index),
                    )
    return locations


def _run_markers(run: ET.Element) -> tuple[MarkedRun, ...]:
    visible_text = _visible_text(run)
    if not visible_text:
        return ()
    run_properties = run.find(f"{WORD}rPr")
    if run_properties is None:
        return ()

    markers: list[MarkedRun] = []
    highlight = run_properties.find(f"{WORD}highlight")
    highlight_value = (
        highlight.get(f"{WORD}val") if highlight is not None else None
    )
    highlight_mechanisms = {
        "yellow": MarkerMechanism.HIGHLIGHT_YELLOW,
        "green": MarkerMechanism.HIGHLIGHT_GREEN,
    }
    if highlight_value in highlight_mechanisms:
        markers.append(
            MarkedRun(
                visible_text=visible_text,
                mechanism=highlight_mechanisms[highlight_value],
                value=highlight_value,
                theme_color=None,
                theme_shade=None,
            )
        )

    color = run_properties.find(f"{WORD}color")
    if color is not None and color.get(f"{WORD}themeColor") == "accent6":
        markers.append(
            MarkedRun(
                visible_text=visible_text,
                mechanism=MarkerMechanism.FONT_COLOR_ACCENT6,
                value=color.get(f"{WORD}val"),
                theme_color=color.get(f"{WORD}themeColor"),
                theme_shade=color.get(f"{WORD}themeShade"),
            )
        )
    return tuple(markers)


def extract_visible_paragraphs(path: Path) -> tuple[tuple[ParagraphLocation, str], ...]:
    """Return exact visible paragraph text across all relevant Word parts."""

    paragraphs: list[tuple[ParagraphLocation, str]] = []
    for part in enumerate_wordprocessing_parts(path):
        table_locations = _table_locations(part)
        for paragraph_index, paragraph in enumerate(part.root.iter(f"{WORD}p")):
            table_location = table_locations.get(id(paragraph))
            paragraphs.append(
                (
                    ParagraphLocation(
                        document_part=part.name,
                        paragraph_index=paragraph_index,
                        table_index=table_location[0] if table_location else None,
                        row=table_location[1] if table_location else None,
                        column=table_location[2] if table_location else None,
                        paragraph=table_location[3] if table_location else None,
                    ),
                    _paragraph_visible_text(paragraph),
                )
            )
    return tuple(paragraphs)


def derive_marked_change_census(path: Path) -> ChangeSpecCensus:
    """Derive marked visible runs and their containing paragraphs from OOXML."""

    marked_paragraphs: list[MarkedParagraph] = []
    for part in enumerate_wordprocessing_parts(path):
        table_locations = _table_locations(part)
        for paragraph_index, paragraph in enumerate(part.root.iter(f"{WORD}p")):
            marked_runs = tuple(
                marker
                for run in paragraph.iter(f"{WORD}r")
                for marker in _run_markers(run)
            )
            if not marked_runs:
                continue
            table_location = table_locations.get(id(paragraph))
            marked_paragraphs.append(
                MarkedParagraph(
                    visible_text=_paragraph_visible_text(paragraph),
                    location=ParagraphLocation(
                        document_part=part.name,
                        paragraph_index=paragraph_index,
                        table_index=table_location[0] if table_location else None,
                        row=table_location[1] if table_location else None,
                        column=table_location[2] if table_location else None,
                        paragraph=table_location[3] if table_location else None,
                    ),
                    marked_runs=marked_runs,
                )
            )
    return ChangeSpecCensus(marked_paragraphs=tuple(marked_paragraphs))


def _require_verified_role(
    manifest_path: Path,
    official_dir: Path,
    role: str,
) -> VerifiedOfficialSource:
    entries = [
        item for item in load_source_manifest(manifest_path) if item["role"] == role
    ]
    if len(entries) != 1:
        raise IntegrityError(
            f"Expected exactly one official source with role {role!r}; found {len(entries)}"
        )
    entry = entries[0]
    path = official_dir / entry["filename"]
    if not path.is_file():
        raise IntegrityError(f"Missing official {role} file: {entry['filename']}")
    actual_bytes = path.stat().st_size
    actual_sha256 = sha256_file(path)
    failures: list[str] = []
    if actual_bytes != entry["bytes"]:
        failures.append(
            f"byte-count mismatch expected={entry['bytes']} actual={actual_bytes}"
        )
    if actual_sha256 != entry["sha256"]:
        failures.append(
            f"SHA-256 mismatch expected={entry['sha256']} actual={actual_sha256}"
        )
    if failures:
        raise IntegrityError(
            f"Official {role} verification failed for {entry['filename']}: "
            + "; ".join(failures)
        )
    return VerifiedOfficialSource(
        filename=entry["filename"],
        role=role,
        path=path,
        sha256=actual_sha256,
        byte_count=actual_bytes,
    )


def load_source_requirements(
    path: Path,
    schema_path: Path,
) -> list[SourceRequirement]:
    """Load requirement records with schema, hash, and uniqueness checks."""

    try:
        records = load_jsonl(path)
    except ArtifactValidationError as exc:
        raise IntegrityError(f"Cannot load source requirements: {exc}") from exc

    validator = Draft202012Validator(load_schema(schema_path))
    failures: list[str] = []
    requirements: list[SourceRequirement] = []
    seen: set[str] = set()
    for line_number, record in enumerate(records, 1):
        schema_errors = sorted(
            validator.iter_errors(record), key=lambda error: list(error.path)
        )
        failures.extend(
            f"line {line_number} {'.'.join(map(str, error.path)) or '<record>'}: "
            f"{error.message}"
            for error in schema_errors
        )
        requirement_id = record.get("requirement_id")
        if isinstance(requirement_id, str):
            if requirement_id in seen:
                failures.append(
                    f"line {line_number}: duplicate requirement_id {requirement_id}"
                )
            seen.add(requirement_id)
        exact_text = record.get("exact_source_text_en")
        exact_hash = record.get("exact_text_sha256")
        if (
            isinstance(requirement_id, str)
            and isinstance(exact_text, str)
            and isinstance(exact_hash, str)
            and sha256_text(exact_text) != exact_hash
        ):
            failures.append(
                f"line {line_number}: exact-text hash mismatch for {requirement_id}"
            )
        if not schema_errors:
            try:
                requirements.append(SourceRequirement.from_record(record))
            except (IntegrityError, ValueError) as exc:
                failures.append(f"line {line_number}: {exc}")

    if failures:
        raise IntegrityError("Source-requirement validation failed: " + "; ".join(failures))
    return requirements


def _canonical_texts(
    canonical_source: VerifiedOfficialSource,
    canonical_units: list[dict[str, Any]],
) -> set[str]:
    texts = {
        text
        for _, text in extract_visible_paragraphs(canonical_source.path)
        if text
    }
    texts.update(
        str(unit["source_text_en"])
        for unit in canonical_units
        if unit.get("source_text_en")
    )
    return texts


def verify_change_spec_completeness(
    manifest_path: Path,
    official_dir: Path,
    canonical_units: list[dict[str, Any]],
    source_requirements: list[SourceRequirement],
) -> ChangeSpecCompleteness:
    """Prove every source-derived marked paragraph is canonically accounted for."""

    canonical_source = _require_verified_role(
        manifest_path, official_dir, "canonical_source"
    )
    change_spec = _require_verified_role(
        manifest_path, official_dir, "official_change_spec"
    )
    canonical_texts = _canonical_texts(canonical_source, canonical_units)
    requirement_texts = {
        requirement.exact_source_text_en for requirement in source_requirements
    }
    census = derive_marked_change_census(change_spec.path)
    unaccounted = tuple(
        paragraph.visible_text
        for paragraph in census.marked_paragraphs
        if paragraph.visible_text not in canonical_texts
        and paragraph.visible_text not in requirement_texts
    )
    if unaccounted:
        raise IntegrityError(
            "Marked change-spec paragraphs are not accounted for by canonical "
            f"source or source requirements: {list(unaccounted)}"
        )
    absent_from_canonical = tuple(
        dict.fromkeys(
            paragraph.visible_text
            for paragraph in census.marked_paragraphs
            if paragraph.visible_text not in canonical_texts
        )
    )
    return ChangeSpecCompleteness(
        census=census,
        canonical_paragraph_count=len(canonical_texts),
        absent_from_canonical=absent_from_canonical,
    )


def _location_matches(
    location: ParagraphLocation,
    provenance: SourceProvenance,
) -> bool:
    if location.document_part != provenance.document_part:
        return False
    if provenance.paragraph_index is not None:
        return location.paragraph_index == provenance.paragraph_index
    return (
        location.table_index == provenance.table_index
        and location.row == provenance.row
        and location.column == provenance.column
        and location.paragraph == provenance.paragraph
    )


def _marking_matches(
    marked_runs: tuple[MarkedRun, ...],
    marking: SourceMarking,
) -> bool:
    if marking.marker_type == "highlight":
        expected = {
            "yellow": MarkerMechanism.HIGHLIGHT_YELLOW,
            "green": MarkerMechanism.HIGHLIGHT_GREEN,
        }.get(marking.value)
        return expected is not None and any(
            run.mechanism is expected for run in marked_runs
        )
    if marking.marker_type == "font_color":
        return any(
            run.mechanism is MarkerMechanism.FONT_COLOR_ACCENT6
            and run.value == marking.value
            and run.theme_color == marking.theme_color
            and run.theme_shade == marking.theme_shade
            for run in marked_runs
        )
    return False


def verify_source_requirements(
    requirements_path: Path,
    schema_path: Path,
    manifest_path: Path,
    official_dir: Path,
    canonical_units: list[dict[str, Any]],
) -> SourceRequirementVerification:
    """Verify requirements, marked completeness, linkage, and canonical presence."""

    requirements = load_source_requirements(requirements_path, schema_path)
    canonical_source = _require_verified_role(
        manifest_path, official_dir, "canonical_source"
    )
    change_spec = _require_verified_role(
        manifest_path, official_dir, "official_change_spec"
    )
    canonical_texts = _canonical_texts(canonical_source, canonical_units)
    census = derive_marked_change_census(change_spec.path)

    failures: list[str] = []
    for requirement in requirements:
        if requirement.official_source_filename != change_spec.filename:
            failures.append(
                f"{requirement.requirement_id}: official source is not the "
                "manifest-linked official_change_spec"
            )
        if requirement.source_role != change_spec.role:
            failures.append(f"{requirement.requirement_id}: source role mismatch")
        if requirement.official_source_file_sha256 != change_spec.sha256:
            failures.append(f"{requirement.requirement_id}: source-file SHA-256 mismatch")

        matching_paragraphs = [
            paragraph
            for paragraph in census.marked_paragraphs
            if _location_matches(
                paragraph.location, requirement.source_provenance
            )
        ]
        if not matching_paragraphs:
            failures.append(
                f"{requirement.requirement_id}: marked official source location not found"
            )
            continue
        paragraph = matching_paragraphs[0]
        if paragraph.visible_text != requirement.exact_source_text_en:
            failures.append(
                f"{requirement.requirement_id}: exact requirement text not found at "
                "official source location"
            )
        if not _marking_matches(
            paragraph.marked_runs, requirement.source_provenance.marking
        ):
            failures.append(
                f"{requirement.requirement_id}: marking is not present on a visible "
                "source-text run"
            )
        actual_presence = requirement.exact_source_text_en in canonical_texts
        if actual_presence != requirement.canonical_source_presence:
            failures.append(
                f"{requirement.requirement_id}: canonical source presence mismatch"
            )

    if failures:
        raise IntegrityError(
            "Official source-requirement verification failed: " + "; ".join(failures)
        )
    completeness = verify_change_spec_completeness(
        manifest_path, official_dir, canonical_units, requirements
    )
    return SourceRequirementVerification(
        requirements=tuple(requirements),
        completeness=completeness,
    )


def _immutable_location(
    location: dict[str, Any],
) -> tuple[tuple[str, ProvenanceValue], ...]:
    values: list[tuple[str, ProvenanceValue]] = []
    for key, value in sorted(location.items()):
        if isinstance(value, (str, int, bool)):
            values.append((key, value))
    return tuple(values)


def build_translation_evidence_sources(
    source_units: list[dict[str, Any]],
    requirements: list[SourceRequirement] | tuple[SourceRequirement, ...],
) -> list[EvidenceSource]:
    """Build typed stage inputs with explicit document-insertion eligibility."""

    sources = [
        EvidenceSource(
            evidence_id=str(unit["unit_id"]),
            source_kind=EvidenceSourceKind.CANONICAL_SOURCE_UNIT,
            exact_source_text_en=str(unit["source_text_en"]),
            source_text_sha256=str(unit["source_text_sha256"]),
            source_provenance=EvidenceProvenance(
                source_role="canonical_source",
                document_part=(
                    "word/document.xml"
                    if "table_index" in unit["source_location"]
                    else None
                ),
                location=_immutable_location(unit["source_location"]),
            ),
            requires_translation_evidence=True,
            requires_human_signoff=bool(unit["requires_human_signoff"]),
            final_inclusion_status=FinalInclusionStatus.CANONICAL,
            eligible_for_document_insertion=True,
        )
        for unit in source_units
    ]
    sources.extend(
        EvidenceSource(
            evidence_id=requirement.requirement_id,
            source_kind=EvidenceSourceKind.OFFICIAL_CHANGE_REQUIREMENT,
            exact_source_text_en=requirement.exact_source_text_en,
            source_text_sha256=requirement.exact_text_sha256,
            source_provenance=EvidenceProvenance(
                source_role=requirement.source_role,
                document_part=requirement.source_provenance.document_part,
                location=tuple(
                    (key, value)
                    for key, value in (
                        ("table_index", requirement.source_provenance.table_index),
                        ("row", requirement.source_provenance.row),
                        ("column", requirement.source_provenance.column),
                        ("paragraph", requirement.source_provenance.paragraph),
                        (
                            "paragraph_index",
                            requirement.source_provenance.paragraph_index,
                        ),
                    )
                    if value is not None
                ),
            ),
            requires_translation_evidence=requirement.translation_evidence_required,
            requires_human_signoff=requirement.requires_human_signoff,
            final_inclusion_status=requirement.final_inclusion_status,
            eligible_for_document_insertion=(
                requirement.final_inclusion_status is FinalInclusionStatus.INCLUDE
                and requirement.has_authority_disposition
            ),
        )
        for requirement in requirements
        if requirement.translation_evidence_required
    )
    return sources
