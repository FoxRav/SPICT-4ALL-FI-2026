# Machine-readable source index

`source_units.jsonl` contains 53 extracted source units from the canonical SPICT-4ALL 2026 translation template plus the rendered title as unit `S4A-2026-000`.

`canonical_unit_exceptions.jsonl` records any source unit that cannot be
resolved as exact text at its canonical DOCX location. It is schema, source-hash,
canonical-file-hash, provenance, and authority-state linked. The current title
exception remains authority-required, publication-blocking, and non-insertable.

`source_requirements.jsonl` contains provenance-linked official change requirements in a separate `S4A-REQ-...` namespace. These records may require translation evidence but do not automatically become canonical document content.

The manifest-verified canonical DOCX remains the canonical document/layout and
normal-text source. Source-unit JSONL text never expands the canonical corpus.
Final inclusion of an unresolved exception or requirement requires an explicit
human/source-authority disposition.
