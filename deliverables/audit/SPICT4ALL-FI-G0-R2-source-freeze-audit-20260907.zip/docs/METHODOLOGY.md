# Methodology

The official SPICT translation guidance supplied for this project states that first translations should use an evidence-based translation/cross-cultural adaptation approach, begin with a small group with palliative-care experience, receive wider peer review, be tried in clinical settings, and keep a clear record of the process. It points to WHO translation/adaptation guidance, Beaton et al., and the TRAPD team translation model.

This repository implements those principles as an AI-assisted evidence workflow, not as an AI-only replacement for human review.

## AI-assisted adaptation of the process
1. Lock official files, canonical source units, and provenance-linked official source requirements.
2. Agent A and Agent B independently translate every required evidence source EN->FI, including unresolved requirements that require translation evidence.
3. Agent C compares source+A+B and creates a synthesis with explicit disagreements.
4. A blind model back-translates FI->EN without seeing the source.
5. Critic agents check semantic/clinical drift, omissions, additions, terminology and plain-language quality.
6. Small human expert group adjudicates every unit; machine agreement does not equal approval.
7. Target users/staff test wording in practice as appropriate.
8. Final wording and external review status are recorded.

## Source authority and translation evidence
The manifest-verified canonical template determines normal canonical document
text and layout. Source-unit data is accepted as canonical evidence only after an
exact text-and-location match to that DOCX. A unit that cannot match requires a
schema-validated, file-hash-linked provenance exception; an unresolved exception
is not document-insertable. An official change specification can independently
establish that an explicit change requirement exists even when the canonical
template omits it. The requirement is therefore preserved and may undergo the
complete translation evidence workflow without being promoted into the canonical
unit namespace.

Translation evidence answers how a source would be translated. It does not answer whether that source belongs in the final publication. Inclusion or exclusion requires an explicit human/source-authority disposition. Until then, the conflict remains visible, final source reconciliation is incomplete, and a publication-blocking requirement prevents publication.

The evidence-source contract is immutable and typed. It records source kind,
exact text and hash, provenance, translation and human-review requirements, final
inclusion state, and explicit document-insertion eligibility. Directly resolved
canonical units are insertion-eligible. `S4A-2026-000` remains an unresolved,
non-insertable canonical exception while translation evidence may proceed. An
unresolved official requirement is also not insertable; only an explicit
authority disposition can change either authority state.

## Why this is stronger than a single-model translation
The workflow deliberately separates generation, comparison, blind back-translation, critique and approval. Independent artifacts make errors easier to detect and make the process reproducible.

## What AI cannot establish by itself
- clinical validity
- psychometric validity
- cultural acceptability in real Finnish users
- legal or organisational approval
- external SPICT programme approval

Those require human/evidence steps and must be documented separately.

## Official methodology links
- SPICT translations: https://www.spict.org.uk/translations/
- WHO process of translation/adaptation of instruments: http://www.who.int/substance_abuse/research_tools/translation/en/
- Beaton DE et al., Guidelines for the process of cross-cultural adaptation of self-report measures: https://pubmed.ncbi.nlm.nih.gov/11124735/
- TRAPD / Cross-Cultural Survey Guidelines: http://ccsg.isr.umich.edu/index.php/chapters/translation-chapter/translation-overview
