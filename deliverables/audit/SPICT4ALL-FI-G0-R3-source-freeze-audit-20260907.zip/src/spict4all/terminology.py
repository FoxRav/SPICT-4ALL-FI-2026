"""Provenance-controlled extraction and validation of terminology evidence."""

from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, TypedDict, cast

import pymupdf
from jsonschema import Draft202012Validator

from .artifacts import load_schema
from .errors import IntegrityError
from .hashing import sha256_file
from .units import load_source_units, validate_source_units

TERMINOLOGY_ROLE = "TERMINOLOGY_REFERENCE"
# Source-unit JSON objects are strictly validated before this boundary type is used.
SourceUnitRecord = dict[str, Any]
GLOSSARY_COLUMNS = (
    "term_id",
    "concept_en",
    "candidate_fi",
    "approved_fi",
    "definition_context",
    "source_refs",
    "source_evidence_strength",
    "status",
    "clinical_risk",
    "decision_note",
    "decided_by",
    "decision_date",
)


class GlossaryStatus(str, Enum):
    DISCOVERED = "DISCOVERED"
    CANDIDATE = "CANDIDATE"
    CONFLICT = "CONFLICT"
    HUMAN_REVIEW_REQUIRED = "HUMAN_REVIEW_REQUIRED"
    APPROVED = "APPROVED"


@dataclass(frozen=True)
class TerminologySource:
    source_id: str
    filename: str
    byte_count: int
    sha256: str
    detected_file_type: str
    title: str | None
    publisher_organisation: str | None
    publication_version_date: str | None
    source_url: str | None
    licence_reuse_status: str
    provenance_status: str
    terminology_role: str
    evidence_level: int
    metadata_confidence: str
    metadata_evidence: tuple[str, ...]
    unresolved_metadata: tuple[str, ...]

    @classmethod
    def from_record(cls, record: dict[str, object]) -> TerminologySource:
        return cls(
            source_id=cast(str, record["source_id"]),
            filename=cast(str, record["filename"]),
            byte_count=cast(int, record["byte_count"]),
            sha256=cast(str, record["sha256"]),
            detected_file_type=cast(str, record["detected_file_type"]),
            title=cast(str | None, record["title"]),
            publisher_organisation=cast(
                str | None, record["publisher_organisation"]
            ),
            publication_version_date=cast(
                str | None, record["publication_version_date"]
            ),
            source_url=cast(str | None, record["source_url"]),
            licence_reuse_status=cast(str, record["licence_reuse_status"]),
            provenance_status=cast(str, record["provenance_status"]),
            terminology_role=cast(str, record["terminology_role"]),
            evidence_level=cast(int, record["evidence_level"]),
            metadata_confidence=cast(str, record["metadata_confidence"]),
            metadata_evidence=tuple(cast(list[str], record["metadata_evidence"])),
            unresolved_metadata=tuple(cast(list[str], record["unresolved_metadata"])),
        )


class SourceLocation(TypedDict):
    kind: str
    number: int
    source_record_id: str | None


class ExtractedTerm(TypedDict):
    entry_id: str
    term_fi: str
    term_en: str | None
    term_en_origin: str
    definition: str | None
    context: str | None
    source_id: str
    source_filename: str
    source_sha256: str
    source_location: SourceLocation
    source_organisation: str | None
    source_date_version: str | None
    extraction_method: str
    source_fragment: str
    source_provided_fields: list[str]
    project_interpretation: str | None
    approval_status: str
    notes: list[str]


@dataclass(frozen=True)
class TerminologyValidationResult:
    source_count: int
    extracted_count: int
    conflict_count: int
    approved_count: int
    relevance_count: int


class PdfTextExtractor:
    """Local connector isolating PyMuPDF's partially untyped API."""

    def __init__(self) -> None:
        self._documents: dict[Path, pymupdf.Document] = {}

    def _document(self, path: Path) -> pymupdf.Document:
        document = self._documents.get(path)
        if document is None:
            # PyMuPDF 1.28.2 does not type this constructor for strict callers.
            document = pymupdf.open(path)  # type: ignore[no-untyped-call]
            self._documents[path] = document
        return document

    def page_count(self, path: Path) -> int:
        return int(self._document(path).page_count)

    def page_text(self, path: Path, page_number: int) -> str:
        # PyMuPDF 1.28.2 does not type Page.get_text for strict callers.
        return str(
            self._document(path)[page_number - 1].get_text("text")  # type: ignore[no-untyped-call]
        )

    def close(self) -> None:
        for document in self._documents.values():
            # PyMuPDF 1.28.2 does not type Document.close for strict callers.
            document.close()  # type: ignore[no-untyped-call]
        self._documents.clear()


def _load_json_object(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise IntegrityError(f"Cannot read JSON file {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise IntegrityError(f"Expected a JSON object: {path}")
    return cast(dict[str, object], value)


def _validate_schema(
    value: object,
    schema_path: Path,
    label: str,
) -> None:
    errors = sorted(
        Draft202012Validator(load_schema(schema_path)).iter_errors(value),
        key=lambda error: list(error.path),
    )
    if errors:
        details = "; ".join(
            f"{'.'.join(map(str, error.path)) or '<record>'}: {error.message}"
            for error in errors
        )
        raise IntegrityError(f"{label} schema validation failed: {details}")


def load_terminology_sources(
    manifest_path: Path,
    schema_path: Path,
) -> tuple[TerminologySource, ...]:
    value = _load_json_object(manifest_path)
    _validate_schema(value, schema_path, "Terminology source manifest")
    records = cast(list[dict[str, object]], value["sources"])
    sources = tuple(TerminologySource.from_record(record) for record in records)
    source_ids = [source.source_id for source in sources]
    filenames = [source.filename for source in sources]
    if len(source_ids) != len(set(source_ids)):
        raise IntegrityError("Terminology source manifest has duplicate source IDs")
    if len(filenames) != len(set(filenames)):
        raise IntegrityError("Terminology source manifest has duplicate filenames")
    return sources


def verify_terminology_sources(
    repository: Path,
    manifest_path: Path,
    schema_path: Path,
) -> tuple[TerminologySource, ...]:
    sources = load_terminology_sources(manifest_path, schema_path)
    source_root = repository / "data/Sanasto"
    actual_filenames = {path.name for path in source_root.iterdir() if path.is_file()}
    manifested_filenames = {source.filename for source in sources}
    if actual_filenames != manifested_filenames:
        raise IntegrityError(
            "Terminology source manifest membership mismatch: "
            f"missing={sorted(actual_filenames - manifested_filenames)} "
            f"extra={sorted(manifested_filenames - actual_filenames)}"
        )

    failures: list[str] = []
    for source in sources:
        if source.terminology_role != TERMINOLOGY_ROLE:
            failures.append(f"{source.source_id}: invalid terminology role")
        path = source_root / source.filename
        actual_bytes = path.stat().st_size
        actual_sha256 = sha256_file(path)
        if actual_bytes != source.byte_count:
            failures.append(f"{source.source_id}: byte-count mismatch")
        if actual_sha256 != source.sha256:
            failures.append(f"{source.source_id}: SHA-256 mismatch")
        if source.detected_file_type == "PDF":
            if path.read_bytes()[:5] != b"%PDF-":
                failures.append(f"{source.source_id}: PDF signature mismatch")
        elif source.detected_file_type == "CSV_SEMICOLON_UTF8":
            try:
                first_line = path.read_text(encoding="utf-8-sig").splitlines()[0]
            except (OSError, UnicodeError, IndexError) as exc:
                failures.append(f"{source.source_id}: unreadable CSV: {exc}")
            else:
                if ";" not in first_line or "properties.prefLabel.fi" not in first_line:
                    failures.append(f"{source.source_id}: CSV structure mismatch")
        else:
            failures.append(f"{source.source_id}: unsupported detected file type")
    if failures:
        raise IntegrityError(
            "Terminology source verification failed: " + "; ".join(failures)
        )
    return sources


def _join_nonempty(values: list[str]) -> str | None:
    nonempty = [value for value in values if value]
    return " | ".join(nonempty) if nonempty else None


def _csv_terms(path: Path, source: TerminologySource) -> list[ExtractedTerm]:
    records: list[ExtractedTerm] = []
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle, delimiter=";")
            if reader.fieldnames is None:
                raise IntegrityError(f"Terminology CSV has no header: {path}")
            for row_number, row in enumerate(reader, 2):
                term_fi = (row.get("properties.prefLabel.fi") or "").strip()
                if row_number == 2 or not term_fi:
                    continue
                term_en = (row.get("properties.prefLabel.en") or "").strip() or None
                definition = (
                    (row.get("properties.definition.fi") or "").strip() or None
                )
                context = _join_nonempty(
                    [
                        (row.get("properties.note.fi") or "").strip(),
                        (row.get("properties.scopeNote.fi") or "").strip(),
                    ]
                )
                if (
                    source.title is not None
                    and term_fi == source.title
                    and term_en is None
                    and definition is None
                    and context is None
                ):
                    continue
                source_record_id = (row.get("id") or "").strip() or None
                provided = ["term_fi"]
                if term_en is not None:
                    provided.append("term_en")
                if definition is not None:
                    provided.append("definition")
                if context is not None:
                    provided.append("context")
                fragment = json.dumps(
                    {
                        "context": context,
                        "definition": definition,
                        "term_en": term_en,
                        "term_fi": term_fi,
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                records.append(
                    ExtractedTerm(
                        entry_id=f"TERM-EVID-{source.source_id.removeprefix('TERM-SRC-')}-ROW-{row_number:04d}",
                        term_fi=term_fi,
                        term_en=term_en,
                        term_en_origin=(
                            "SOURCE_EXPLICIT" if term_en is not None else "NOT_PROVIDED"
                        ),
                        definition=definition,
                        context=context,
                        source_id=source.source_id,
                        source_filename=source.filename,
                        source_sha256=source.sha256,
                        source_location=SourceLocation(
                            kind="CSV_ROW",
                            number=row_number,
                            source_record_id=source_record_id,
                        ),
                        source_organisation=source.publisher_organisation,
                        source_date_version=source.publication_version_date,
                        extraction_method="CSV_EXPLICIT_COLUMN_EXTRACTION",
                        source_fragment=fragment,
                        source_provided_fields=provided,
                        project_interpretation=None,
                        approval_status="DISCOVERED",
                        notes=[],
                    )
                )
    except (OSError, UnicodeError, csv.Error) as exc:
        raise IntegrityError(f"Cannot extract terminology CSV {path}: {exc}") from exc
    return records


def _pdf_terms(
    source_root: Path,
    sources_by_id: dict[str, TerminologySource],
    rules_path: Path,
    rule_schema_path: Path,
) -> list[ExtractedTerm]:
    rule_set = _load_json_object(rules_path)
    _validate_schema(rule_set, rule_schema_path, "Terminology PDF extraction rules")
    rules = cast(list[dict[str, object]], rule_set["rules"])
    records: list[ExtractedTerm] = []
    seen_ids: set[str] = set()
    extractor = PdfTextExtractor()
    try:
        for rule in rules:
            entry_id = cast(str, rule["entry_id"])
            if entry_id in seen_ids:
                raise IntegrityError(f"Duplicate terminology extraction ID: {entry_id}")
            seen_ids.add(entry_id)
            source_id = cast(str, rule["source_id"])
            source = sources_by_id.get(source_id)
            if source is None or source.detected_file_type != "PDF":
                raise IntegrityError(
                    f"{entry_id}: PDF rule references invalid source {source_id}"
                )
            source_path = source_root / source.filename
            page_number = cast(int, rule["page"])
            if page_number > extractor.page_count(source_path):
                raise IntegrityError(f"{entry_id}: PDF page is out of range")
            page_text = extractor.page_text(source_path, page_number)
            exact_fragment = cast(str, rule["exact_fragment"])
            if exact_fragment not in page_text:
                raise IntegrityError(
                    f"{entry_id}: exact PDF fragment not found on page {page_number}"
                )
            term_en = cast(str | None, rule["term_en"])
            definition = cast(str | None, rule["definition"])
            context = cast(str | None, rule["context"])
            provided = ["term_fi"]
            if term_en is not None:
                provided.append("term_en")
            if definition is not None:
                provided.append("definition")
            if context is not None:
                provided.append("context")
            records.append(
                ExtractedTerm(
                    entry_id=entry_id,
                    term_fi=cast(str, rule["term_fi"]),
                    term_en=term_en,
                    term_en_origin=(
                        "SOURCE_EXPLICIT" if term_en is not None else "NOT_PROVIDED"
                    ),
                    definition=definition,
                    context=context,
                    source_id=source.source_id,
                    source_filename=source.filename,
                    source_sha256=source.sha256,
                    source_location=SourceLocation(
                        kind="PDF_PAGE",
                        number=page_number,
                        source_record_id=None,
                    ),
                    source_organisation=source.publisher_organisation,
                    source_date_version=source.publication_version_date,
                    extraction_method="PDF_EXACT_FRAGMENT_RULE",
                    source_fragment=exact_fragment,
                    source_provided_fields=provided,
                    project_interpretation=None,
                    approval_status="DISCOVERED",
                    notes=[],
                )
            )
    finally:
        extractor.close()
    return records


def extract_terminology(
    repository: Path,
    sources: tuple[TerminologySource, ...],
    rules_path: Path,
    rule_schema_path: Path,
) -> list[ExtractedTerm]:
    source_root = repository / "data/Sanasto"
    sources_by_id = {source.source_id: source for source in sources}
    records: list[ExtractedTerm] = []
    for source in sources:
        if source.detected_file_type == "CSV_SEMICOLON_UTF8":
            records.extend(_csv_terms(source_root / source.filename, source))
    records.extend(
        _pdf_terms(source_root, sources_by_id, rules_path, rule_schema_path)
    )
    return sorted(records, key=lambda record: record["entry_id"])


def serialize_extracted_terms(records: list[ExtractedTerm]) -> str:
    return "".join(
        json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
        for record in records
    )


def validate_extracted_terms(
    records: list[ExtractedTerm],
    schema_path: Path,
) -> None:
    failures: list[str] = []
    seen: set[str] = set()
    for line_number, record in enumerate(records, 1):
        try:
            _validate_schema(record, schema_path, f"Extracted term line {line_number}")
        except IntegrityError as exc:
            failures.append(str(exc))
        entry_id = record["entry_id"]
        if entry_id in seen:
            failures.append(f"Duplicate extracted terminology ID: {entry_id}")
        seen.add(entry_id)
        if record["project_interpretation"] is not None:
            failures.append(
                f"{entry_id}: extraction output must not contain project interpretation"
            )
        source_values = {
            "term_fi": record["term_fi"],
            "term_en": record["term_en"],
            "definition": record["definition"],
            "context": record["context"],
        }
        for field in record["source_provided_fields"]:
            value = source_values[field]
            if isinstance(value, str) and value not in record["source_fragment"]:
                failures.append(
                    f"{entry_id}: source-provided {field} is absent from source fragment"
                )
    if failures:
        raise IntegrityError("Extracted terminology validation failed: " + "; ".join(failures))


def load_glossary(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if tuple(reader.fieldnames or ()) != GLOSSARY_COLUMNS:
                raise IntegrityError(
                    f"Glossary columns mismatch: expected={GLOSSARY_COLUMNS} "
                    f"actual={tuple(reader.fieldnames or ())}"
                )
            return [dict(row) for row in reader]
    except (OSError, UnicodeError, csv.Error) as exc:
        raise IntegrityError(f"Cannot read terminology glossary {path}: {exc}") from exc


def validate_glossary(rows: list[dict[str, str]]) -> tuple[dict[str, str], ...]:
    failures: list[str] = []
    approved: list[dict[str, str]] = []
    seen: set[str] = set()
    for row_number, row in enumerate(rows, 2):
        term_id = row.get("term_id", "").strip()
        if not term_id or term_id in seen:
            failures.append(f"row {row_number}: missing or duplicate term_id {term_id!r}")
        seen.add(term_id)
        try:
            status = GlossaryStatus(row.get("status", ""))
        except ValueError:
            failures.append(f"row {row_number}: invalid glossary status")
            continue
        approved_fi = row.get("approved_fi", "").strip()
        if status is GlossaryStatus.APPROVED:
            required = (
                "concept_en",
                "approved_fi",
                "source_refs",
                "decision_note",
                "decided_by",
                "decision_date",
            )
            missing = [field for field in required if not row.get(field, "").strip()]
            if missing:
                failures.append(
                    f"row {row_number}: APPROVED terminology missing {missing}"
                )
            else:
                approved.append(row)
        elif approved_fi:
            failures.append(
                f"row {row_number}: unapproved terminology cannot set approved_fi"
            )
    if failures:
        raise IntegrityError("Terminology glossary validation failed: " + "; ".join(failures))
    return tuple(approved)


def derive_conflicts(records: list[ExtractedTerm]) -> list[dict[str, object]]:
    english_groups: dict[str, list[ExtractedTerm]] = defaultdict(list)
    for record in records:
        if record["term_en"] is not None:
            english_groups[record["term_en"].casefold()].append(record)
    conflicts: list[dict[str, object]] = []
    for concept_key, group in sorted(english_groups.items()):
        finnish_terms = sorted({record["term_fi"] for record in group})
        if len(finnish_terms) < 2:
            continue
        conflicts.append(
            {
                "conflict_id": f"TERM-CONFLICT-{len(conflicts) + 1:03d}",
                "conflict_type": "DIFFERENT_FINNISH_TERMS_FOR_EXPLICIT_ENGLISH_CONCEPT",
                "concept_en": concept_key,
                "candidate_fi": finnish_terms,
                "source_entry_ids": sorted(record["entry_id"] for record in group),
                "status": "HUMAN_REVIEW_REQUIRED",
            }
        )
    finnish_groups: dict[str, list[ExtractedTerm]] = defaultdict(list)
    for record in records:
        finnish_groups[record["term_fi"].casefold()].append(record)
    for term_key, group in sorted(finnish_groups.items()):
        definitions = sorted(
            {record["definition"] for record in group if record["definition"] is not None}
        )
        if len(definitions) < 2:
            continue
        explicit_english = sorted(
            {record["term_en"] for record in group if record["term_en"] is not None}
        )
        conflicts.append(
            {
                "conflict_id": f"TERM-CONFLICT-{len(conflicts) + 1:03d}",
                "conflict_type": "DIFFERENT_DEFINITIONS_FOR_FINNISH_TERM",
                "concept_en": explicit_english[0] if len(explicit_english) == 1 else None,
                "candidate_fi": sorted({record["term_fi"] for record in group}),
                "definitions": definitions,
                "source_entry_ids": sorted(record["entry_id"] for record in group),
                "status": "HUMAN_REVIEW_REQUIRED",
                "term_key": term_key,
            }
        )
    return conflicts


def serialize_conflicts(conflicts: list[dict[str, object]]) -> str:
    return "".join(
        json.dumps(conflict, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
        for conflict in conflicts
    )


def build_relevance_rows(
    source_units: list[SourceUnitRecord],
    records: list[ExtractedTerm],
    conflicts: list[dict[str, object]],
) -> list[dict[str, str]]:
    validate_source_units(source_units)
    conflict_concepts = {
        concept
        for conflict in conflicts
        if isinstance((concept := conflict.get("concept_en")), str)
    }
    rows: list[dict[str, str]] = []
    for unit in source_units:
        source_text = cast(str, unit["source_text_en"])
        normalized_source = source_text.casefold()
        for record in records:
            term_en = record["term_en"]
            if term_en is None or len(term_en) < 4:
                continue
            pattern = rf"(?<!\w){re.escape(term_en.casefold())}(?!\w)"
            if re.search(pattern, normalized_source) is None:
                continue
            conflict_count = int(term_en.casefold() in conflict_concepts)
            rows.append(
                {
                    "unit_id": cast(str, unit["unit_id"]),
                    "english_phrase_concept": term_en,
                    "matched_terminology_source": record["source_id"],
                    "finnish_source_term": record["term_fi"],
                    "match_method": "CASEFOLD_EXACT_PHRASE_BOUNDARY",
                    "confidence": "HIGH" if not conflict_count else "AMBIGUOUS",
                    "human_review_required": "true",
                    "conflict_count": str(conflict_count),
                }
            )
    return sorted(
        rows,
        key=lambda row: (
            row["unit_id"],
            row["english_phrase_concept"],
            row["matched_terminology_source"],
            row["finnish_source_term"],
        ),
    )


def serialize_relevance_rows(rows: list[dict[str, str]]) -> str:
    columns = (
        "unit_id",
        "english_phrase_concept",
        "matched_terminology_source",
        "finnish_source_term",
        "match_method",
        "confidence",
        "human_review_required",
        "conflict_count",
    )
    lines = ["\t".join(columns)]
    lines.extend("\t".join(row[column] for column in columns) for row in rows)
    return "\n".join(lines) + "\n"


def duplicate_finnish_term_groups(
    records: list[ExtractedTerm],
) -> dict[str, list[ExtractedTerm]]:
    groups: dict[str, list[ExtractedTerm]] = defaultdict(list)
    for record in records:
        groups[record["term_fi"].casefold()].append(record)
    return {
        key: group
        for key, group in sorted(groups.items())
        if len({record["source_id"] for record in group}) > 1
    }


def render_terminology_report(
    sources: tuple[TerminologySource, ...],
    records: list[ExtractedTerm],
    conflicts: list[dict[str, object]],
    glossary_rows: list[dict[str, str]],
    approved_count: int,
    relevance_count: int,
) -> str:
    duplicates = duplicate_finnish_term_groups(records)
    high_risk = [
        row["concept_en"]
        for row in glossary_rows
        if row.get("clinical_risk") == "HIGH"
    ]
    lines = [
        "# Terminology evidence report",
        "",
        "Status: terminology evidence only; no project terminology is approved.",
        "",
        "## Counts",
        f"- Registered terminology/reference sources: {len(sources)}",
        f"- Extracted source-provided terminology entries: {len(records)}",
        f"- Mechanical source-unit relevance matches: {relevance_count}",
        f"- Explicit terminology conflicts: {len(conflicts)}",
        f"- Cross-source duplicate Finnish term groups: {len(duplicates)}",
        f"- Glossary concepts requiring human review: {len(glossary_rows)}",
        f"- Approved project terminology: {approved_count}",
        "",
        "## Registered source files",
    ]
    for source in sources:
        lines.extend(
            [
                f"- `{source.filename}`",
                f"  - SHA-256: `{source.sha256}`",
                f"  - Bytes: {source.byte_count}",
                f"  - Role: `{source.terminology_role}`; evidence level {source.evidence_level}",
                f"  - Provenance: `{source.provenance_status}`; metadata confidence `{source.metadata_confidence}`",
                f"  - Licence/reuse: `{source.licence_reuse_status}`",
                *(
                    [f"  - Unresolved: {'; '.join(source.unresolved_metadata)}"]
                    if source.unresolved_metadata
                    else []
                ),
            ]
        )
    lines.extend(
        [
            "",
            "## Duplicate concepts and source terms",
        ]
    )
    if duplicates:
        for key, group in duplicates.items():
            refs = ", ".join(
                f"{record['source_id']}:{record['entry_id']}" for record in group
            )
            lines.append(f"- `{key}` — {refs}")
    else:
        lines.append("- None detected.")
    lines.extend(["", "## Conflicts and different definitions"])
    if conflicts:
        for conflict in conflicts:
            lines.append(
                f"- `{conflict['conflict_id']}` `{conflict['conflict_type']}`: "
                f"{', '.join(cast(list[str], conflict['candidate_fi']))}; "
                f"human review required."
            )
    else:
        lines.append("- No mechanical conflict was detected; this is not a human resolution.")
    lines.extend(
        [
            "",
            "## Currency and source-authority differences",
            "- Dated 2018, 2019, and 2022 materials remain evidence, but currency must be checked by a human terminology reviewer before approval.",
            "- Evidence levels 2 and 3 are kept distinct. Missing CSV publisher, date, URL, and licence metadata are explicit and do not block G0.",
            "- No source is classified as canonical SPICT authority.",
            "",
            "## Concepts without an approved Finnish equivalent",
        ]
    )
    lines.extend(
        f"- `{row['concept_en']}` — `{row['status']}`"
        for row in glossary_rows
        if row.get("status") != GlossaryStatus.APPROVED.value
    )
    lines.extend(["", "## High-risk clinical concepts requiring human review"])
    lines.extend(f"- `{concept}`" for concept in high_risk)
    lines.extend(
        [
            "",
            "## Source-unit relevance",
            f"- Conservative exact English phrase matching produced {relevance_count} rows.",
            "- Zero matches are permitted. Finnish-only source terms are not assigned English equivalents by inference.",
            "- Ambiguous matches, if present, remain flagged for human review.",
            "",
            "## Authority boundary",
            "- Level 1 English SPICT source text and official change requirements define what must be translated.",
            "- These Finnish materials are terminology/reference evidence only. They cannot add, remove, redefine, or override English SPICT source content.",
            "- No AI suggestion or extracted term is mandatory. Only terminology with explicit `APPROVED` status and human disposition may later be supplied to both independent forward translators.",
            "",
        ]
    )
    return "\n".join(lines)


def validate_terminology_evidence(repository: Path) -> TerminologyValidationResult:
    sources = verify_terminology_sources(
        repository,
        repository / "terminology/sources/terminology_source_manifest.json",
        repository / "schemas/terminology_source_manifest.schema.json",
    )
    records = extract_terminology(
        repository,
        sources,
        repository / "terminology/sources/pdf_extraction_rules.json",
        repository / "schemas/terminology_pdf_extraction_rule.schema.json",
    )
    validate_extracted_terms(
        records, repository / "schemas/terminology_extracted_entry.schema.json"
    )
    expected_extracted = serialize_extracted_terms(records)
    extracted_path = repository / "terminology/extracted/terminology_evidence.jsonl"
    try:
        actual_extracted = extracted_path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise IntegrityError(f"Cannot read extracted terminology artifact: {exc}") from exc
    if actual_extracted != expected_extracted:
        raise IntegrityError(
            "Extracted terminology artifact is not reproducible from registered sources"
        )

    conflicts = derive_conflicts(records)
    conflicts_path = repository / "terminology/conflicts/terminology_conflicts.jsonl"
    if conflicts_path.read_text(encoding="utf-8") != serialize_conflicts(conflicts):
        raise IntegrityError("Terminology conflict artifact is not reproducible")

    glossary_rows = load_glossary(repository / "terminology/terms.csv")
    approved = validate_glossary(glossary_rows)
    source_units = load_source_units(repository / "data/source_units.jsonl")
    relevance = build_relevance_rows(source_units, records, conflicts)
    relevance_path = repository / "terminology/reports/source_unit_terminology_map.tsv"
    if relevance_path.read_text(encoding="utf-8") != serialize_relevance_rows(relevance):
        raise IntegrityError("Terminology relevance map is not reproducible")
    expected_report = render_terminology_report(
        sources,
        records,
        conflicts,
        glossary_rows,
        len(approved),
        len(relevance),
    )
    report_path = repository / "terminology/reports/TERMINOLOGY_EVIDENCE_REPORT.md"
    if report_path.read_text(encoding="utf-8") != expected_report:
        raise IntegrityError("Terminology evidence report is not reproducible")
    return TerminologyValidationResult(
        source_count=len(sources),
        extracted_count=len(records),
        conflict_count=len(conflicts),
        approved_count=len(approved),
        relevance_count=len(relevance),
    )
