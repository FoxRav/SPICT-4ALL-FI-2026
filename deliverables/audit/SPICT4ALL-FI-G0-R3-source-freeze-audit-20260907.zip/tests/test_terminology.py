from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from spict4all.errors import IntegrityError
from spict4all.hashing import sha256_file
from spict4all.requirements import verify_canonical_units_against_source
from spict4all.terminology import (
    ExtractedTerm,
    build_relevance_rows,
    derive_conflicts,
    extract_terminology,
    load_glossary,
    load_terminology_sources,
    validate_extracted_terms,
    validate_glossary,
    validate_terminology_evidence,
    verify_terminology_sources,
)
from spict4all.units import load_source_units

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "terminology/sources/terminology_source_manifest.json"
MANIFEST_SCHEMA = ROOT / "schemas/terminology_source_manifest.schema.json"
RULES = ROOT / "terminology/sources/pdf_extraction_rules.json"
RULE_SCHEMA = ROOT / "schemas/terminology_pdf_extraction_rule.schema.json"
EXTRACTED_SCHEMA = ROOT / "schemas/terminology_extracted_entry.schema.json"


def _sources_and_records():
    sources = verify_terminology_sources(ROOT, MANIFEST, MANIFEST_SCHEMA)
    records = extract_terminology(ROOT, sources, RULES, RULE_SCHEMA)
    return sources, records


def test_terminology_source_hashes_are_deterministic() -> None:
    sources = verify_terminology_sources(ROOT, MANIFEST, MANIFEST_SCHEMA)
    assert len(sources) == 5
    for source in sources:
        path = ROOT / "data/Sanasto" / source.filename
        assert sha256_file(path) == source.sha256
        assert path.stat().st_size == source.byte_count


def test_duplicate_terminology_source_record_fails(tmp_path: Path) -> None:
    value = json.loads(MANIFEST.read_text(encoding="utf-8"))
    value["sources"].append(copy.deepcopy(value["sources"][0]))
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    with pytest.raises(IntegrityError, match="duplicate source IDs"):
        load_terminology_sources(path, MANIFEST_SCHEMA)


def test_terminology_source_provenance_fields_are_required(
    tmp_path: Path,
) -> None:
    value = json.loads(MANIFEST.read_text(encoding="utf-8"))
    del value["sources"][0]["metadata_evidence"]
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    with pytest.raises(IntegrityError, match="metadata_evidence"):
        load_terminology_sources(path, MANIFEST_SCHEMA)


def test_terminology_source_cannot_claim_canonical_role(tmp_path: Path) -> None:
    value = json.loads(MANIFEST.read_text(encoding="utf-8"))
    value["sources"][0]["terminology_role"] = "CANONICAL_SOURCE"
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    with pytest.raises(IntegrityError, match="TERMINOLOGY_REFERENCE"):
        load_terminology_sources(path, MANIFEST_SCHEMA)


def test_extracted_term_cannot_claim_inferred_english_as_source_text() -> None:
    _, records = _sources_and_records()
    record = copy.deepcopy(records[0])
    record["term_en"] = "fabricated English equivalent"
    record["term_en_origin"] = "SOURCE_EXPLICIT"
    record["source_provided_fields"].append("term_en")
    with pytest.raises(IntegrityError, match="absent from source fragment"):
        validate_extracted_terms([record], EXTRACTED_SCHEMA)


def test_unapproved_term_cannot_enter_mandatory_glossary() -> None:
    rows = load_glossary(ROOT / "terminology/terms.csv")
    rows[0]["approved_fi"] = "fixture-only"
    with pytest.raises(IntegrityError, match="unapproved terminology"):
        validate_glossary(rows)


def test_terminology_conflict_is_preserved() -> None:
    _, records = _sources_and_records()
    first = copy.deepcopy(records[0])
    second = copy.deepcopy(records[1])
    first["term_en"] = second["term_en"] = "shared explicit concept"
    first["term_en_origin"] = second["term_en_origin"] = "SOURCE_EXPLICIT"
    first["term_fi"] = "source candidate one"
    second["term_fi"] = "source candidate two"
    conflicts = derive_conflicts([first, second])
    assert len(conflicts) == 1
    assert conflicts[0]["status"] == "HUMAN_REVIEW_REQUIRED"


def test_relevance_map_allows_zero_and_flags_ambiguous_matches(make_unit) -> None:
    unit = make_unit(text="A shared explicit concept appears here.")
    _, records = _sources_and_records()
    no_match = copy.deepcopy(records[0])
    no_match["term_en"] = None
    assert build_relevance_rows([unit], [no_match], []) == []

    candidates: list[ExtractedTerm] = []
    for index, term_fi in enumerate(("candidate one", "candidate two")):
        candidate = copy.deepcopy(records[index])
        candidate["term_en"] = "shared explicit concept"
        candidate["term_en_origin"] = "SOURCE_EXPLICIT"
        candidate["term_fi"] = term_fi
        candidates.append(candidate)
    conflicts = derive_conflicts(candidates)
    rows = build_relevance_rows([unit], candidates, conflicts)
    assert len(rows) == 2
    assert {row["confidence"] for row in rows} == {"AMBIGUOUS"}
    assert {row["human_review_required"] for row in rows} == {"true"}


def test_terminology_validation_cannot_expand_canonical_english_corpus() -> None:
    units = load_source_units(ROOT / "data/source_units.jsonl")
    before = verify_canonical_units_against_source(
        ROOT / "sources/manifests/source_manifest.json",
        ROOT / "sources/official",
        units,
        ROOT / "data/canonical_unit_exceptions.jsonl",
        ROOT / "schemas/canonical_unit_exception.schema.json",
    ).canonical_docx_texts
    result = validate_terminology_evidence(ROOT)
    after = verify_canonical_units_against_source(
        ROOT / "sources/manifests/source_manifest.json",
        ROOT / "sources/official",
        units,
        ROOT / "data/canonical_unit_exceptions.jsonl",
        ROOT / "schemas/canonical_unit_exception.schema.json",
    ).canonical_docx_texts
    assert before == after
    assert result.source_count == 5
    assert result.approved_count == 0
