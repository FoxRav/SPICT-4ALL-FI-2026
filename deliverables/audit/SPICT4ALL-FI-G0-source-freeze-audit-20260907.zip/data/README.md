# Machine-readable source index

`source_units.jsonl` contains 53 extracted source units from the canonical SPICT-4ALL 2026 translation template plus the rendered title as unit `S4A-2026-000`.

`source_requirements.jsonl` contains provenance-linked official change requirements in a separate `S4A-REQ-...` namespace. These records may require translation evidence but do not automatically become canonical document content.

The canonical DOCX remains the canonical document/layout source. The JSONL files are indexed working representations with per-record SHA-256 hashes. Final inclusion of an unresolved requirement requires an explicit human/source-authority disposition.
