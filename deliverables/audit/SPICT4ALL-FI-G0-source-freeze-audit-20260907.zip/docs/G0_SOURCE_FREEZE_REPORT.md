# WP-G0-SOURCE-FREEZE-001 report

Date: 2026-09-07  
Repository: `F:\-DEV-\120.Samin-PDF`  
Baseline Git commit: `4f4cb3ffd61b2366d6c4aae507916eca2932bf36`

## Outcome

G0 source freeze passes. All four official source files remain unchanged and hash verified. The 53 canonical source units remain unchanged, unique, contiguous, and exact-text hash matched. One official source requirement is now recorded in a separate stable namespace and verified against its exact OOXML source location and 2026 marking.

The source requirement participates in translation evidence preparation but is not a canonical source unit and cannot be inserted automatically into a final DOCX. Its final inclusion remains unresolved.

## Official source hashes

- `20260130-Using-SPICT-4ALL-2025.docx`: `1b8ee715051ca53a27d0a2261a7f879face8a57727fbfd12fc6a830ef1c155ca` (111045 bytes)
- `20260521-Edits-for-SPICT-4ALL-translations-2025-and-2026.docx`: `0fff175b57c66f0dd45cd18c58b599758122e5285892c07da52ddf8a9130a27d` (68949 bytes)
- `20260521-Word-template-SPICT-4ALL-translations-2026.docx`: `aea5e489ffc93f57ab3666572f65044fba8375aa5dda897d0ef2988c3a9f8581` (66914 bytes)
- `20260521-Word-template-SPICT-4ALL-translations-2026.pdf`: `d22418ca1d1b68a2be762bcdf48ae0e6ad41ac41c8e3d76b419e9062d4357f72` (223468 bytes)

Canonical source-unit count: 53.  
Official source-requirement count: 1.  
Translation-evidence source count after G0: 54.

## Unresolved conflicts

1. `S4A-REQ-2026-001`
   - Exact English: `A liver transplant is not possible.`
   - Exact-text SHA-256: `1b64512313b1820b42bf0692274c18740b11a2c395750605cfda023afcc7bc93`
   - Official source: `20260521-Edits-for-SPICT-4ALL-translations-2025-and-2026.docx`
   - Provenance: `word/document.xml`, table 0, row 31, column 2, paragraph 0
   - 2026 marking: font color `w:val=385623`, theme `accent6`, shade `80`
   - Canonical source presence: false
   - Final inclusion: `UNRESOLVED`
   - Publication blocking: true
2. `S4A-2026-000`
   - Translation and review evidence may be prepared.
   - Authoritative final title wording still requires human/source-authority disposition.

## Blocker semantics

The unresolved discrepancies do not block canonical source verification, G0, engineering, independent Agent A or Agent B evidence preparation, synthesis, blind back-translation, critic review, or human adjudication.

They block final source reconciliation. `S4A-REQ-2026-001` blocks final publication while unresolved. Neither discrepancy permits a claim that the final source set is authority-resolved.

## Files created

- `data/source_requirements.jsonl`
- `docs/G0_SOURCE_FREEZE_REPORT.md`
- `schemas/source_requirement.schema.json`
- `scripts/create_g0_audit_zip.py`
- `src/spict4all/requirements.py`
- `tests/test_requirements.py`
- `deliverables/audit/SPICT4ALL-FI-G0-source-freeze-audit-20260907.zip`
- `deliverables/audit/SPICT4ALL-FI-G0-source-freeze-audit-20260907.zip.sha256`

## Files changed

- `.gitignore`
- `README.md`
- `config/quality_gates.yaml`
- `data/README.md`
- `docs/METHODOLOGY.md`
- `docs/OFFICIAL_TRANSLATION_GUIDANCE.md`
- `docs/SOURCE_PROVENANCE.md`
- `docs/WORKFLOW.md`
- `prompts/01-agent-a-forward.md`
- `prompts/02-agent-b-forward.md`
- `prompts/03-agent-c-synthesis.md`
- `schemas/translation_candidate.schema.json`
- `src/spict4all/artifacts.py`
- `src/spict4all/cli.py`
- `src/spict4all/gates.py`
- `tests/test_artifacts.py`
- `tools.ps1`

No file under `sources/official/` was modified, renamed, rewritten, or regenerated.

## Tests and checks

- `.\tools.ps1 -Task Test`: PASS=50, FAIL=0; audit-packaging run result `50 passed in 0.72s`.
- `.\tools.ps1 -Task VerifySources`: PASS=6, FAIL=0; four official files, 53 canonical units, and one official requirement verified.
- `.\tools.ps1 -Task ValidateRequirements`: PASS=1, FAIL=0.
- `.venv\Scripts\python.exe -m compileall -q src scripts tests`: PASS=1, FAIL=0; exit code 0 with no output.
- Total counted checks: PASS=58, FAIL=0.
- Audit ZIP open: PASS=1, FAIL=0.
- Audit ZIP CRC: PASS=1, FAIL=0.
- Archived-file index SHA-256 verification: PASS=89, FAIL=0.
- Required official archive members: PASS=4, FAIL=0.
- Forbidden archive members: 0.

Source verification result: PASS. The exact change-spec text, text hash, source-file linkage, source-file hash, source role, OOXML location and 2026 marking were verified. Exact absence from the canonical Word template was verified. Expected requirement-ID coverage prevents the conflict from silently disappearing.

## Assumptions and decisions

- The canonical Word template remains the canonical document/layout source.
- The official change specification is authoritative evidence that its explicitly marked 2026 requirement exists.
- No inference was made about final inclusion.
- `AUTHORITY_DECISION_REQUIRED` on `S4A-2026-000` remains an authority blocker for final wording, not a translation-stage blocker.
- Per the project owner's selected audit convention, the exact final ZIP SHA-256 is stored in an external `.sha256` sidecar because an archive cannot contain its own final SHA-256 without changing that hash.

## Remaining blockers

- Human/source-authority inclusion or exclusion disposition for `S4A-REQ-2026-001`.
- Human/source-authority disposition for authoritative final title wording in `S4A-2026-000`.
- The bootstrap-noted page-image inspection limitation remains separate from this G0 source-freeze verification.

## Git status

Expected final uncommitted status after audit packaging:

```text
 M .gitignore
 M README.md
 M config/quality_gates.yaml
 M data/README.md
 M docs/METHODOLOGY.md
 M docs/OFFICIAL_TRANSLATION_GUIDANCE.md
 M docs/SOURCE_PROVENANCE.md
 M docs/WORKFLOW.md
 M prompts/01-agent-a-forward.md
 M prompts/02-agent-b-forward.md
 M prompts/03-agent-c-synthesis.md
 M schemas/translation_candidate.schema.json
 M src/spict4all/artifacts.py
 M src/spict4all/cli.py
 M src/spict4all/gates.py
 M tests/test_artifacts.py
 M tools.ps1
?? data/source_requirements.jsonl
?? deliverables/audit/SPICT4ALL-FI-G0-source-freeze-audit-20260907.zip
?? deliverables/audit/SPICT4ALL-FI-G0-source-freeze-audit-20260907.zip.sha256
?? docs/G0_SOURCE_FREEZE_REPORT.md
?? schemas/source_requirement.schema.json
?? scripts/create_g0_audit_zip.py
?? src/spict4all/requirements.py
?? tests/test_requirements.py
```

`git diff --stat` for tracked files before packaging:

```text
 .gitignore                                |  1 +
 README.md                                 |  9 +++-
 config/quality_gates.yaml                 | 18 ++++---
 data/README.md                            |  4 +-
 docs/METHODOLOGY.md                       |  9 +++-
 docs/OFFICIAL_TRANSLATION_GUIDANCE.md     |  7 +++
 docs/SOURCE_PROVENANCE.md                 | 11 +++-
 docs/WORKFLOW.md                          | 19 +++++--
 prompts/01-agent-a-forward.md             |  6 ++-
 prompts/02-agent-b-forward.md             |  2 +-
 prompts/03-agent-c-synthesis.md           |  3 +-
 schemas/translation_candidate.schema.json |  2 +-
 src/spict4all/artifacts.py                | 17 +++++--
 src/spict4all/cli.py                      | 83 +++++++++++++++++++++++++++----
 src/spict4all/gates.py                    | 59 ++++++++++++++++++++++
 tests/test_artifacts.py                   | 15 ++++++
 tools.ps1                                 |  5 +-
 17 files changed, 233 insertions(+), 37 deletions(-)
```

Nothing was committed or pushed.

## No-translation confirmation

No Finnish translation content, Finnish candidate, model-generated translation, Agent A run, or Agent B run was created during WP-G0-SOURCE-FREEZE-001. No model API was called.
