# Translation workflow

## Stage 0 - freeze source
Run `python scripts/verify_sources.py`. Any official-file, canonical-unit, or source-requirement integrity failure is a hard stop.

G0 distinguishes:
- canonical source units, which define the official template text/layout;
- official source requirements, which preserve explicit change-specification evidence in a separate namespace;
- final inclusion decisions, which require explicit human/source-authority disposition.

An explicit unresolved authority conflict may pass G0 when it remains provenance-linked and truthfully unresolved. G0 permits translation evidence work; it does not assert that the final source set is authority-resolved.

## Stage 1 - Agent A
Input: all translation-evidence sources: canonical records from `data/source_units.jsonl` plus records in `data/source_requirements.jsonl` where `translation_evidence_required` is true; approved terminology only; project rules.
Output: `work/agent-a/candidates.jsonl`.
Agent A must not see B.

## Stage 2 - Agent B
Same source input. Output: `work/agent-b/candidates.jsonl`.
Agent B must not see A.

## Stage 3 - Agent C synthesis
Input: exact source + A + B + approved glossary.
Output: `work/synthesis/synthesis.jsonl` and `work/synthesis/disagreements.tsv`.
Every changed/combined decision gets a short auditable note.

## Stage 4 - blind back-translation
Create an input containing only `unit_id` + synthesized Finnish text. No English source text.
Output: `work/backtranslation/backtranslation.jsonl`.

## Stage 5 - critics
Run at least:
- clinical/semantic critic
- Finnish plain-language/cultural critic
- adversarial independent critic
Output structured issue records in `work/critics/`.

## Stage 6 - human adjudication
Use `templates/human_review.tsv`. Every translation-evidence source must be explicitly signed off. High-risk or disputed sources require clinical reviewer attention even if models agree. Translation adjudication does not resolve whether a noncanonical source requirement belongs in the final publication.

## Stage 6A - final source reconciliation
Record explicit source-authority/human dispositions for every authority-required canonical wording and official source requirement. `INCLUDE` or `EXCLUDE` is a source-set decision; neither may be inferred from model output, translation completion, or reviewer agreement. `S4A-2026-000` may proceed through translation and review, but its authoritative final title wording remains subject to this disposition.

## Stage 7 - document generation
Only after G0-G5 pass and final source reconciliation has no unresolved inclusion decisions:
- copy official DOCX
- insert approved Finnish text after the corresponding English line
- never alter original English
- never insert an unresolved official source requirement automatically
- preserve original layout and marks
- render DOCX to images and inspect every page

## Stage 8 - field testing / external review
Record target-user/staff testing, revisions, and University of St Andrews / SPICT programme review state. Do not call a draft approved before that state is documented.
