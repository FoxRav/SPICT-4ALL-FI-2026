"""Official source-requirement integrity and evidence-source preparation."""

from __future__ import annotations

import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .artifacts import load_schema
from .errors import ArtifactValidationError, IntegrityError
from .hashing import sha256_file, sha256_text
from .jsonl import load_jsonl
from .sources import load_source_manifest

EXPECTED_REQUIREMENT_IDS = frozenset({"S4A-REQ-2026-001"})
CANONICAL_SOURCE_FILENAME = "20260521-Word-template-SPICT-4ALL-translations-2026.docx"
WORD_NAMESPACE = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
WORD = f"{{{WORD_NAMESPACE}}}"


@dataclass(frozen=True)
class SourceRequirement:
    """A provenance-locked official requirement outside the canonical unit namespace."""

    requirement_id: str
    exact_source_text_en: str
    exact_text_sha256: str
    official_source_filename: str
    official_source_file_sha256: str
    source_role: str
    source_provenance: dict[str, object]
    change_year: int
    canonical_source_presence: bool
    conflict_status: str
    translation_evidence_required: bool
    source_authority_confirmation_required: bool
    final_inclusion_status: str
    publication_blocking: bool

    @classmethod
    def from_record(cls, record: dict[str, Any]) -> SourceRequirement:
        return cls(
            requirement_id=record["requirement_id"],
            exact_source_text_en=record["exact_source_text_en"],
            exact_text_sha256=record["exact_text_sha256"],
            official_source_filename=record["official_source_filename"],
            official_source_file_sha256=record["official_source_file_sha256"],
            source_role=record["source_role"],
            source_provenance=dict(record["source_provenance"]),
            change_year=record["change_year"],
            canonical_source_presence=record["canonical_source_presence"],
            conflict_status=record["conflict_status"],
            translation_evidence_required=record["translation_evidence_required"],
            source_authority_confirmation_required=record[
                "source_authority_confirmation_required"
            ],
            final_inclusion_status=record["final_inclusion_status"],
            publication_blocking=record["publication_blocking"],
        )


def _load_document_xml(path: Path) -> ET.Element:
    try:
        with zipfile.ZipFile(path, "r") as document:
            xml = document.read("word/document.xml")
        return ET.fromstring(xml)
    except (OSError, KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        raise IntegrityError(f"Cannot inspect official DOCX {path}: {exc}") from exc


def _paragraph_text(paragraph: ET.Element) -> str:
    return "".join(node.text or "" for node in paragraph.iter(f"{WORD}t"))


def _all_paragraph_text(root: ET.Element) -> tuple[str, ...]:
    return tuple(_paragraph_text(paragraph) for paragraph in root.iter(f"{WORD}p"))


def _requirement_location_paragraph(
    root: ET.Element, requirement: SourceRequirement
) -> ET.Element:
    provenance = requirement.source_provenance
    try:
        table = list(root.iter(f"{WORD}tbl"))[int(provenance["table_index"])]
        row = table.findall(f"{WORD}tr")[int(provenance["row"])]
        cell = row.findall(f"{WORD}tc")[int(provenance["column"])]
        return cell.findall(f"{WORD}p")[int(provenance["paragraph"])]
    except (IndexError, KeyError, TypeError, ValueError) as exc:
        raise IntegrityError(
            f"Invalid official source location for {requirement.requirement_id}"
        ) from exc


def load_source_requirements(
    path: Path,
    schema_path: Path,
    *,
    expected_ids: frozenset[str] = EXPECTED_REQUIREMENT_IDS,
) -> list[SourceRequirement]:
    """Load records with schema, hash, uniqueness, and completeness checks."""

    try:
        records = load_jsonl(path)
    except ArtifactValidationError as exc:
        raise IntegrityError(f"Cannot load source requirements: {exc}") from exc
    if not records:
        raise IntegrityError("Source-requirement index is empty")

    validator = Draft202012Validator(load_schema(schema_path))
    failures: list[str] = []
    requirements: list[SourceRequirement] = []
    seen: set[str] = set()
    for line_number, record in enumerate(records, 1):
        schema_errors = sorted(
            validator.iter_errors(record), key=lambda error: list(error.path)
        )
        failures.extend(
            f"line {line_number} {'.'.join(map(str, error.path)) or '<record>'}: "
            f"{error.message}"
            for error in schema_errors
        )
        requirement_id = record.get("requirement_id")
        if isinstance(requirement_id, str):
            if requirement_id in seen:
                failures.append(
                    f"line {line_number}: duplicate requirement_id {requirement_id}"
                )
            seen.add(requirement_id)
        exact_text = record.get("exact_source_text_en")
        exact_hash = record.get("exact_text_sha256")
        if (
            isinstance(requirement_id, str)
            and isinstance(exact_text, str)
            and isinstance(exact_hash, str)
            and sha256_text(exact_text) != exact_hash
        ):
            failures.append(f"line {line_number}: exact-text hash mismatch for {requirement_id}")
        if not schema_errors:
            requirements.append(SourceRequirement.from_record(record))

    missing = sorted(expected_ids - seen)
    extra = sorted(seen - expected_ids)
    if missing:
        failures.append(f"missing required source requirement IDs: {missing}")
    if extra:
        failures.append(f"unexpected source requirement IDs: {extra}")
    if failures:
        raise IntegrityError("Source-requirement validation failed: " + "; ".join(failures))
    return requirements


def verify_source_requirements(
    requirements_path: Path,
    schema_path: Path,
    manifest_path: Path,
    official_dir: Path,
) -> list[SourceRequirement]:
    """Verify source linkage, exact official text, and canonical absence."""

    requirements = load_source_requirements(requirements_path, schema_path)
    manifest_by_filename = {
        item["filename"]: item for item in load_source_manifest(manifest_path)
    }
    canonical_path = official_dir / CANONICAL_SOURCE_FILENAME
    canonical_text = "\n".join(_all_paragraph_text(_load_document_xml(canonical_path)))

    failures: list[str] = []
    document_roots: dict[str, ET.Element] = {}
    for requirement in requirements:
        manifest_entry = manifest_by_filename.get(requirement.official_source_filename)
        if manifest_entry is None:
            failures.append(
                f"{requirement.requirement_id}: official source is not linked in manifest"
            )
            continue
        if manifest_entry["role"] != requirement.source_role:
            failures.append(f"{requirement.requirement_id}: source role mismatch")
        if manifest_entry["sha256"] != requirement.official_source_file_sha256:
            failures.append(f"{requirement.requirement_id}: source-file SHA-256 mismatch")

        source_path = official_dir / requirement.official_source_filename
        if not source_path.is_file():
            failures.append(f"{requirement.requirement_id}: linked official source file is missing")
            continue
        if sha256_file(source_path) != requirement.official_source_file_sha256:
            failures.append(f"{requirement.requirement_id}: linked official source file changed")
            continue

        root = document_roots.setdefault(
            requirement.official_source_filename, _load_document_xml(source_path)
        )
        paragraph = _requirement_location_paragraph(root, requirement)
        if _paragraph_text(paragraph) != requirement.exact_source_text_en:
            failures.append(
                f"{requirement.requirement_id}: exact requirement text not found at official "
                "source location"
            )
        marking = requirement.source_provenance["marking"]
        if not isinstance(marking, dict):
            raise IntegrityError(
                f"Invalid official source marking for {requirement.requirement_id}"
            )
        expected_color = (
            marking["w_val"],
            marking["theme_color"],
            marking["theme_shade"],
        )
        colors = {
            (
                node.get(f"{WORD}val"),
                node.get(f"{WORD}themeColor"),
                node.get(f"{WORD}themeShade"),
            )
            for node in paragraph.iter(f"{WORD}color")
        }
        if expected_color not in colors:
            failures.append(
                f"{requirement.requirement_id}: expected 2026 font-color marking "
                f"not found at official source location; "
                f"actual={sorted(str(item) for item in colors)}"
            )
        actual_canonical_presence = requirement.exact_source_text_en in canonical_text
        if actual_canonical_presence != requirement.canonical_source_presence:
            failures.append(
                f"{requirement.requirement_id}: canonical source presence mismatch"
            )

    if failures:
        raise IntegrityError("Official source-requirement verification failed: " + "; ".join(failures))
    return requirements


def build_translation_evidence_sources(
    source_units: list[dict[str, Any]],
    requirements: list[SourceRequirement],
) -> list[dict[str, Any]]:
    """Build immutable-stage inputs without treating requirements as canonical units."""

    sources = [dict(unit, source_kind="canonical_source_unit") for unit in source_units]
    sources.extend(
        {
            "unit_id": requirement.requirement_id,
            "source_text_en": requirement.exact_source_text_en,
            "source_text_sha256": requirement.exact_text_sha256,
            "source_kind": "official_source_requirement",
            "final_inclusion_status": requirement.final_inclusion_status,
        }
        for requirement in requirements
        if requirement.translation_evidence_required
    )
    return sources
