from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from spict4all.errors import GateError, IntegrityError
from spict4all.gates import (
    assert_publication_allowed,
    assert_source_reconciliation_resolved,
)
from spict4all.hashing import sha256_file, sha256_text
from spict4all.requirements import (
    build_translation_evidence_sources,
    load_source_requirements,
    verify_source_requirements,
)
from spict4all.units import load_source_units

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "schemas/source_requirement.schema.json"
MANIFEST = ROOT / "sources/manifests/source_manifest.json"
OFFICIAL = ROOT / "sources/official"
REQUIREMENTS = ROOT / "data/source_requirements.jsonl"
CANONICAL = OFFICIAL / "20260521-Word-template-SPICT-4ALL-translations-2026.docx"
CANONICAL_SHA256 = "aea5e489ffc93f57ab3666572f65044fba8375aa5dda897d0ef2988c3a9f8581"


def _record() -> dict[str, Any]:
    return json.loads(REQUIREMENTS.read_text(encoding="utf-8"))


def _write(path: Path, records: list[dict[str, Any]]) -> Path:
    path.write_text(
        "".join(json.dumps(record, ensure_ascii=False) + "\n" for record in records),
        encoding="utf-8",
    )
    return path


def test_valid_source_requirement_passes() -> None:
    requirements = verify_source_requirements(
        REQUIREMENTS, SCHEMA, MANIFEST, OFFICIAL
    )
    assert [item.requirement_id for item in requirements] == ["S4A-REQ-2026-001"]


def test_duplicate_requirement_id_fails(tmp_path: Path) -> None:
    record = _record()
    path = _write(tmp_path / "requirements.jsonl", [record, record])
    with pytest.raises(IntegrityError, match="duplicate requirement_id"):
        load_source_requirements(path, SCHEMA)


def test_mutated_requirement_source_text_fails(tmp_path: Path) -> None:
    record = _record()
    record["exact_source_text_en"] = "Mutated source text."
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="exact-text hash mismatch"):
        load_source_requirements(path, SCHEMA)


def test_mutated_source_text_with_matching_hash_fails_official_verification(
    tmp_path: Path,
) -> None:
    record = _record()
    record["exact_source_text_en"] = "Mutated source text."
    record["exact_text_sha256"] = sha256_text(record["exact_source_text_en"])
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="exact requirement text not found"):
        verify_source_requirements(path, SCHEMA, MANIFEST, OFFICIAL)


def test_mutated_requirement_text_hash_fails(tmp_path: Path) -> None:
    record = _record()
    record["exact_text_sha256"] = "0" * 64
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="exact-text hash mismatch"):
        load_source_requirements(path, SCHEMA)


def test_missing_official_source_linkage_fails(tmp_path: Path) -> None:
    record = _record()
    record["official_source_filename"] = "missing-official-source.docx"
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="not linked in manifest"):
        verify_source_requirements(path, SCHEMA, MANIFEST, OFFICIAL)


def test_missing_required_provenance_fails(tmp_path: Path) -> None:
    record = _record()
    del record["source_provenance"]
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="source_provenance"):
        load_source_requirements(path, SCHEMA)


def test_invalid_source_file_sha256_fails(tmp_path: Path) -> None:
    record = _record()
    record["official_source_file_sha256"] = "invalid"
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="official_source_file_sha256"):
        load_source_requirements(path, SCHEMA)


def test_invalid_final_inclusion_state_fails(tmp_path: Path) -> None:
    record = _record()
    record["final_inclusion_status"] = "SILENTLY_INCLUDED"
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="final_inclusion_status"):
        load_source_requirements(path, SCHEMA)


def test_missing_requirement_fails(tmp_path: Path) -> None:
    record = _record()
    record["requirement_id"] = "S4A-REQ-2026-002"
    path = _write(tmp_path / "requirements.jsonl", [record])
    with pytest.raises(IntegrityError, match="missing required source requirement IDs"):
        load_source_requirements(path, SCHEMA)


def test_exact_change_spec_text_is_found_and_canonical_is_unchanged() -> None:
    before = sha256_file(CANONICAL)
    verify_source_requirements(REQUIREMENTS, SCHEMA, MANIFEST, OFFICIAL)
    after = sha256_file(CANONICAL)
    assert before == after == CANONICAL_SHA256


def test_unresolved_conflict_allows_translation_evidence_preparation() -> None:
    units = load_source_units(ROOT / "data/source_units.jsonl")
    requirements = verify_source_requirements(
        REQUIREMENTS, SCHEMA, MANIFEST, OFFICIAL
    )
    evidence_sources = build_translation_evidence_sources(units, requirements)
    assert len(units) == 53
    assert len(evidence_sources) == 54
    assert evidence_sources[-1]["unit_id"] == "S4A-REQ-2026-001"


def test_unresolved_conflict_blocks_reconciliation_and_publication() -> None:
    units = load_source_units(ROOT / "data/source_units.jsonl")
    requirements = verify_source_requirements(
        REQUIREMENTS, SCHEMA, MANIFEST, OFFICIAL
    )
    with pytest.raises(GateError, match="S4A-REQ-2026-001"):
        assert_source_reconciliation_resolved(units, requirements)
    with pytest.raises(GateError, match="S4A-REQ-2026-001"):
        assert_publication_allowed(units, requirements)
