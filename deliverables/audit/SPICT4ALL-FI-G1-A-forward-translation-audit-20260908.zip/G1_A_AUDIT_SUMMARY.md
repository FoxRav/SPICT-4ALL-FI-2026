# G1 Forward Translation A audit

Work package: **WP-G1-A-AUDIT-PACKAGE-001**. Original run: WP-G1-A-INDEPENDENT-FORWARD-TRANSLATION-001.
Role: **Forward Translator A**. Actual model: **GPT-6**. Exact backend variant/effort unavailable.

**54 expected / 54 translated: 53 canonical source units + 1 source requirement. All candidates remain DRAFT.**
No human approval is inferred. No clinical validation is claimed. Mechanical validation results are integrity checks, not approval of translation quality.

Agent B was not inspected. No synthesis was performed. No G2 was performed. No sibling worktree was inspected or packaged. No back-translation or critic output based on another candidate was inspected or included. No translation content was regenerated, changed, or synthesized. No commit or push was performed.

S4A-2026-000 authority remains unresolved and publication-blocking; the normalized title remains canonical but non-insertable pending authority disposition. S4A-REQ-2026-001 remains noncanonical, unresolved, publication-blocking, and non-insertable. Its inclusion as translation evidence is not promotion into canonical source. The genuine wording uncertainty remains **frailty / hauraus**. Original source-authority and human-signoff requirements are preserved.

## Included evidence and exclusion boundary

Every existing non-cache/non-temporary file under work/agent-a is preserved byte-for-byte, including its original check logs, source-linked candidates, initial wording, self-edit history, run metadata, report, Git snapshot, hash manifest, and all four Python tools. The explicit no-cache/temp requirement takes precedence over literal inclusion of temporary subdirectories; excluded directories are listed in the audit manifest and were not traversed. No other work directory is opened or included, even for .gitkeep placeholders.

Every recorded G1 run input is included. Relevant frozen official source files, source and governance ledgers, five terminology reference files, glossary, human decisions, and T0/T1 evidence are included. Supplementary T0/T1 files are the dependency closure needed to rerun repository validators, not a claim that Translator A inspected every such file. The glossary still has **0 APPROVED rows**; explicit human ACCEPT wording decisions do not silently promote glossary rows. T1 closure is terminology readiness, not translation approval. Historical pre-G1 reports retain their original state and dates.

Runtime modules, schemas, tests, configurations, and required validator scripts are included for independent checks. Tests and source code may mention other workflow roles or construct artificial test fixtures; these are not Agent B translation artifacts. Native DOCX sources retain their OOXML container format; no nested .zip audit deliverables are included. No .git, venv, retrieval cache, credentials store, or unrelated deliverable is included. Known credential patterns were screened; this is not a universal proof that all conceivable secrets are absent.

## Independent reproduction and hash coverage

Use Python 3.12+ with requirements-dev.lock installed. Extract into a separate directory and run `python scripts/verify_g1_a_audit.py PATH_TO_ZIP`, keeping the .sha256 and .members.sha256 sidecars beside the ZIP. The verifier maps the original run's absolute F: input paths to exact archive-relative names, never to a sibling or external checkout. It checks all frozen input hashes and recomputes source provenance against packaged official DOCX data in a fresh process using packaged runtime code. Existing evidence files, including their original absolute paths, are unchanged.

The original validate_evidence.py has absolute input paths and therefore is not independently relocatable as written. The new archive verifier supplies the portable archive-relative verification without editing that historical script. Original G1-A checks are additionally rerun against the authorized live worktree after sealing, with new logs directed to ignored audit scratch storage. Repository tests and historical T1 validators run in a fixture made only from authorized source/governance/tooling, with empty historical work placeholders reconstructed from the ledger; those placeholders never enter this ZIP. Source, terminology, candidate, coverage, lint, and type validators are rerun after packaging. Exact post-sealing logs and results are in the SHA-bound .verification.json companion. The internal G1_A_AUDIT_VALIDATION_RESULTS.json records pre-sealing checks and points to that later companion; it makes no circular claim about its own final ZIP bytes.

Sorted member names and fixed ZIP timestamps/permissions are used. G1_A_AUDIT_MANIFEST.json lists all members and hashes payload members excluding itself and G1_A_AUDIT_FILE_HASHES.tsv. The TSV additionally hashes the manifest, but excludes itself. The detached .members.sha256 covers every ZIP member, including both index files. The detached .sha256 hashes the final ZIP. This avoids recursive self-hashes. CRC, exact membership, all member hashes, frozen manifests, candidates, provenance, and exclusion rules are rechecked after reopening the archive.

The original G1 report records 311 repository tests plus 12 Agent A tests passed. This package records newly executed outcomes separately, preserving original logs. Hashes prove byte consistency, not all historical model access; historical independence is the translator's recorded attestation plus explicit collection boundaries and inspectable archive membership. No global G1 completion, clinical validity, or release approval is inferred.
