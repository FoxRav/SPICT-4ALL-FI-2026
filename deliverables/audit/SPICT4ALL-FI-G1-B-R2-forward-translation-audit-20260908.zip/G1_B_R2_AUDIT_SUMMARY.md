# SPICT-4ALL FI — G1-B R2 forward-translation correction audit

Work package: **WP-G1-B-CORRECTION-R2-001**
Packaged: 2026-09-08
Original run: **G1-B-20260908-001** (byte-for-byte unchanged)
Corrected run: **G1-B-20260908-002**
Role: **Forward Translator B**

## Model provenance

- **Actual model used: Cursor Grok 4.6**
- Configured / planned role model in `config/model_roles.yaml`: Claude Fable 5.1 High
- These two identities differ. The discrepancy is preserved and is not rewritten.

## Correction

Independent audit found that the original B run did not apply three explicit
Project Owner wording decisions from `terminology/adjudication/T1_2_HUMAN_REVIEW_REDUCTION_REPORT.md`.
Those decisions pre-date G1 and are authorized input. They are not Agent A evidence.

Exactly five `candidate_fi` fields were changed:

- S4A-2026-001, S4A-2026-042: `terveydentila on heikentynyt`
- S4A-2026-004, S4A-2026-014: `toimintakyky on heikentynyt` (usual/tavanomaiset activities kept)
- S4A-2026-017: `ei ole riittävän hyväkuntoinen syöpähoitoon`

No terminology decision IDs were invented. T-002, T-013 and T-016 remain applied.
No other Finnish candidate was changed. This is not synthesis.

## Coverage

- Expected translation-evidence items: **54**
- Canonical source units: **53** + source requirement **1**
- Original 001 hashes unchanged
- Schema `status`: `READY_FOR_SYNTHESIS` (not human approval)
- No `HUMAN_APPROVED` state

## Independence

- Agent A was not inspected.
- No Agent A translation files are packaged.
- No synthesis was performed.
- No G2 was performed.

## T1 validators

Historical T1 files `src/spict4all/adjudication.py`, `src/spict4all/terminology_closure.py`
and `tests/test_adjudication.py` match baseline commit `2aa066f`. T1 was not weakened
to accommodate G1 evidence. Pytest T1 inventory checks use an isolated G1 hide/restore
fixture. The T1.3 CLI correctly rejects a live work tree that already contains G1 files;
that CLI is therefore not run against a tree that includes G1 evidence.

## Validation

The isolated payload snapshot passed **338 tests** plus source, requirement, canonical,
governance, terminology, compileall, strict mypy, ruff, and G1-B candidate validators.

Verify with `python scripts/verify_g1_b_r2_audit_package.py /path/to/SPICT4ALL-FI-G1-B-R2-forward-translation-audit-20260908.zip` while keeping
the companion hash files alongside the ZIP.

No commit or push was performed.
