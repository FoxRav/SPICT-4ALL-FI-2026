# SPICT-4ALL FI — G1-B forward-translation audit

Work package: **WP-G1-B-AUDIT-PACKAGE-001**
Packaged: 2026-09-08
Forward-run work package: WP-G1-B-INDEPENDENT-FORWARD-TRANSLATION-001
Role: **Forward Translator B**

## Model provenance

- **Actual model used: Cursor Grok 4.6**
- Configured / planned role model in `config/model_roles.yaml`: Claude Fable 5.1 High
- These two identities differ. The discrepancy is preserved and is not rewritten.
- This package does **not** claim that Claude Opus or Claude Fable produced this translation.

## Coverage

- Expected translation-evidence items: **54**
- Translated items: **54**
- Canonical source units: **53** (`S4A-2026-000` … `S4A-2026-052`)
- Source requirements: **1** (`S4A-REQ-2026-001`)
- Missing IDs: 0
- Extra IDs: 0
- Blank Finnish candidates: 0
- Approved glossary rows in `terminology/terms.csv`: **0**
- Human terminology decisions applied: T-002, T-013, T-016

## Independence

- Agent A was not inspected.
- No Agent A translation files are packaged.
- No synthesis was performed.
- No G2 was performed.
- No back-translation files are packaged.
- No critic output based on another candidate is packaged.
- No sibling worktree content was packaged.

## Approval and validation claims

- No human approval is inferred.
- No clinical validation is claimed.
- G1 as a two-agent gate is not complete: this package is Agent B evidence only.
- Schema `status` recorded by the sealed run is `READY_FOR_SYNTHESIS` for all 54 items. In this repository that value marks completed independent forward-run output. It is **not** human approval and **not** G2 execution.
- Translation evidence was **not** rewritten to `DRAFT` or to any other status. No `HUMAN_APPROVED` state is present. All candidates remain unapproved draft translation evidence in the methodological sense.

## Source authority preserved unchanged

- `S4A-2026-000` authority remains **UNRESOLVED** and not document-insertable.
- `S4A-REQ-2026-001` remains a noncanonical official change requirement, **UNRESOLVED**, and **publication-blocking**. Translating it did not promote it into canonical source.

## Genuine wording uncertainties recorded by the run

| unit_id | severity | type | note |
|---|---|---|---|
| S4A-2026-000 | BLOCKER | unresolved_source_authority | S4A-2026-000 has final_inclusion_status UNRESOLVED and eligible_for_document_insertion false in the frozen evidence contract. Authoritative final title wording awaits Stage 6A source-authority disposition. This candidate is translation evidence only. |
| S4A-2026-000 | MAJOR | terminology_unresolved | 'Supportive care' has no approved Finnish project term. 'tukea antava hoito' keeps a plain descriptive reading; 'tukihoito' would pull toward oncology supportive treatment and may be narrower than the SPICT sense. Human decision required. |
| S4A-2026-002 | MINOR | source_ambiguity | 'that are getting worse' can attach to 'health problems' alone or to both alternatives. Finnish follows the nearest-antecedent reading and attaches it to 'terveysongelmia'. The source ambiguity is flagged, not resolved. |
| S4A-2026-006 | MAJOR | terminology_unresolved | T-003: no approved Finnish term for 'carer'. 'omaishoitaja' would add a Finnish informal-care agreement status the source does not state; 'hoitaja' would overlap professional staff. Descriptive rendering used. Human decision required. |
| S4A-2026-021 | MAJOR | terminology_unresolved | T-009: 'frailty' has no approved Finnish project term. 'hauraus' stays in a plain register but is vaguer than the clinical concept; 'hauraus-raihnausoireyhtymä' and 'gerastenia' would raise the register and may add an age limit the source does not state. Human decision required. |
| S4A-2026-025 | MINOR | source_idiom | 'the chest is at its best' is English plain-language idiom. Rendered as the chest/rib cage being at its best. A Finnish reviewer should confirm the intended baseline-breathing sense. |
| S4A-2026-045 | MINOR | terminology_unresolved | 'chest infections' rendered as infections of the chest/rib-cage area to stay close to the source noun. Finnish everyday wording more often says hengitystieinfektio, which may be broader. Reviewer should confirm the intended scope. |
| S4A-2026-046 | MAJOR | terminology_unresolved | T-003: no approved Finnish term for 'carer'; the same descriptive rendering as S4A-2026-006 is used. Human decision required and should be consistent across both units. |
| S4A-2026-047 | MINOR | terminology_unresolved | 'ongoing disability' rendered as continuing functional limitation. 'vamma' or 'vammaisuus' could read as a disability-status claim the source does not make. Reviewer should confirm. |
| S4A-2026-049 | NOTE | terminology_unresolved | T-018 was closed as not requiring a pre-G1 term. 'hengelliset' can lean religious in Finnish, while English 'spiritual' may include existential concerns. Carried as a note for synthesis and human review. |
| S4A-2026-050 | MINOR | terminology_unresolved | 'specialist help' rendered as asiantuntija-apua. 'erikoislääkäri' would narrow it to physicians and a Finnish special-level palliative-care tier would add a service level the source does not name. |
| S4A-2026-052 | NOTE | untranslated_verbatim | Retained identical to the source as a proper name and version identifier. |
| S4A-REQ-2026-001 | BLOCKER | unresolved_source_authority | S4A-REQ-2026-001 has final_inclusion_status UNRESOLVED, publication_blocking true and eligible_for_document_insertion false. That authority state is unchanged by this run. Only an explicit source-authority disposition can resolve it. |

Authority blockers are source-set states, not wording approvals.

## Validation

The isolated payload snapshot passed **328 tests** plus source, requirement, canonical, governance, terminology, compileall, strict mypy, ruff, G1-B candidate, and T1.3 closure validators. Full command outputs are in `G1_B_AUDIT_VALIDATION_RESULTS.json`.

Official `.docx` members are original source documents in native OOXML form, not nested audit archives.

## Hash coverage

Members are sorted. ZIP timestamps and permissions are fixed. `G1_B_AUDIT_MANIFEST.json` lists every member and hashes payload members except itself and `G1_B_AUDIT_FILE_HASHES.tsv`. The internal TSV hashes every member except itself, including the manifest. The detached `.members.sha256` hashes every ZIP member. The `.zip.sha256` file hashes the ZIP.

Verify with `python scripts/verify_g1_b_audit_package.py /path/to/SPICT4ALL-FI-G1-B-forward-translation-audit-20260908.zip` while keeping the companion hash files alongside the ZIP.

G1_B_GIT_STATE.txt records the actual dirty/untracked state. No commit or push was performed. Existing G1-B Finnish candidates were packaged byte-for-byte.
