"""Build work/agent-b/candidates.jsonl from authored Finnish text plus frozen sources."""

from pathlib import Path

from spict4all.g1_forward_runner import build_run

ROOT = Path(__file__).resolve().parents[1]
AUTHORED = ROOT / "work/agent-b/agent_b_translations.json"
DESTINATION = ROOT / "work/agent-b/candidates.jsonl"

if __name__ == "__main__":
    records = build_run(ROOT, AUTHORED, DESTINATION)
    print(f"WROTE {DESTINATION.relative_to(ROOT).as_posix()} records={len(records)}")
