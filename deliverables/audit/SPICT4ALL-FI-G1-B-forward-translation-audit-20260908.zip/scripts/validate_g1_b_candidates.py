"""Validate the Agent B forward-translation candidates against frozen sources."""

import json
from pathlib import Path

from spict4all.g1_forward_runner import validate_run

ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "work/agent-b/candidates.jsonl"

if __name__ == "__main__":
    result = validate_run(ROOT, CANDIDATES, translator_role="forward_translation_B")
    print(json.dumps(result, ensure_ascii=False, indent=2))
