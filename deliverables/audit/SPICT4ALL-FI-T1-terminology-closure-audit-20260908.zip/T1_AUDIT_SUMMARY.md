# SPICT-4ALL FI — T1 terminology closure audit

Project: rigorous, evidence-traceable Finnish adaptation of official SPICT-4ALL 2026.
Package: WP-T1-AUDIT-PACKAGE-001, 2026-09-08.
T1 purpose: terminology evidence collection, human-review preparation, review reduction and pre-G1 closure. This is not a translation stage.

**Final T1 status: READY_FOR_G1. 29 concepts reviewed. 0 pre-G1 terminology blockers. 0 active Sami-review items.**

## Explicit human decisions

- T-002: elinikää lyhentävät terveydentilat — Project Owner.
- T-013: hengityskone — Project Owner.
- T-016: kokonaisvaltainen hoito — Sami / domain expert, as reported by Project Owner.

These three ACCEPT records preserve explicit human project decisions, with original decision dates unprovided. No AI suggestion became APPROVED merely because a model proposed it. The controlled glossary still contains 0 APPROVED entries. No G1 translation was performed. Unresolved stylistic/non-material wording may proceed to independent A/B translation and synthesis.

The Project Owner removed T-003, T-018 and T-027 from mandatory pre-G1 review. Frailty (T-009) remains already discussed, without invented final wording; its missing disposition is not a pre-G1 blocker. T1_3_project_owner_disposition.json and T1_TERMINOLOGY_CLOSURE_REPORT.md supersede historical review-priority recommendations.

## Exact validation results and independent reproduction

The isolated payload snapshot passed **311 tests** and all 13 commands: pytest; official sources; source requirements; canonical units; governance; terminology; compileall; strict mypy; ruff; T1, T1.1, T1.2 and T1.3 validators. Full command outputs are in T1_AUDIT_VALIDATION_RESULTS.json. The isolated test run explicitly imported src/spict4all from the copied payload, not the original checkout.

Use Python 3.12+ in a new virtual environment. Install requirements-dev.lock, then install this tree with `python -m pip install --no-deps -e .`. Run the commands in T1_AUDIT_VALIDATION_RESULTS.json from the extracted root. No API key, Firecrawl access, Node.js, .git directory or original checkout is required for the Python tests and validators. Existing test-generated synthetic candidates are test fixtures only, not G1 work.

The delivered ZIP is verified independently after sealing. All repository commands are then rerun. These post-sealing results are in the detached `.verification.json` companion, bound to the final ZIP SHA-256; an immutable archive cannot embed a later result about its own final bytes without changing those bytes.

## Scope and preserved limitations

All terminology/adjudication files (including enrichment, historical queues and ledgers) are included byte-for-byte. Five original terminology reference files and four frozen official source documents are included for recomputation. Current sources, schemas, tests and their required runtime modules are included; older unrelated audit builders, archives, caches and the unrelated root README.md worktree artifact are excluded. The three frozen data/source README files are included because existing integrity checks require their exact bytes; the unchanged terminology/README.md explains the evidence layer. DOCX source documents retain their native OOXML ZIP-container format; there is no nested .zip/archive deliverable.

Source-authority bookkeeping for the normalized title and liver-transplant requirement remains unresolved and publication-blocking where recorded. READY_FOR_G1 is terminology readiness, not publication approval or proof that every workflow gate passed. Three further explicit phrase decisions (less well; less able to manage usual activities; not well enough for cancer treatment) are preserved in T1.2 without invented decision IDs. Frailty's exact final human wording remains unrecorded.

The T1.1 short source fragments, URLs, identifiers, retrieval timestamps and hashes are retained unchanged. Raw Firecrawl response caches are deliberately excluded. All 28 quoted fragments were matched to article markdown in the original T1.1 run; offline reviewers can inspect the retained evidence but cannot independently recompute the excluded raw-response hashes. A fresh fetch may differ. The historical Firecrawl builder requires external retrieval receipts; it is not an offline evidence-regeneration command. Historical artifact-tool TSV builders require the originally documented Node/@oai/artifact-tool runtime. These authoring dependencies are not needed to validate the delivered TSVs.

The T1.1 initial snapshot has two filename-encoding corrections documented in its separate correction record. Original snapshots and all prior decisions are unchanged. The package contains no new terminology research, questions or decisions.

## Hash coverage and immutability

Members are sorted and ZIP timestamps/permissions fixed. T1_AUDIT_MANIFEST.json lists every member and hashes all payload members except itself and T1_AUDIT_FILE_HASHES.tsv. The internal TSV hashes every member except itself, including the manifest. The detached `.members.sha256` hashes **every** ZIP member, including both index files, avoiding an impossible self-hash cycle. The `.zip.sha256` file hashes the ZIP itself.

Verify with `python scripts/verify_t1_audit_package.py /path/to/SPICT4ALL-FI-T1-terminology-closure-audit-20260908.zip` while keeping the .sha256 and .members.sha256 companions alongside it. The verifier independently checks membership, every hash, CRC, frozen official and terminology files, final closure status and zero active Sami items. Creation refuses to overwrite an existing delivery. Cryptographic hashes detect modification; this is not a digital signature or write-once storage guarantee.

T1_GIT_STATE.txt records the actual dirty/untracked state, not a commit claim. No unrelated README worktree content, credentials, .git, temporary files, caches or earlier audit ZIPs are included. No commit or push was performed.
